const fs = require('fs');
const path = require('path');


/**
 * extract environment path as a list
 *
 * @returns {Array<String>}
 */
function getEnvPaths () {
    var envPaths = process.env['path'];
    if (envPaths) {
        return envPaths.split(';');
    } else {
        return [];
    }
}


/**
 * extract npm package directory from environment variables
 *
 * @returns {String}
 */
function getNpmPath () {
    var envPaths = getEnvPaths();
    for (var i = 0; i < envPaths.length; i++) {
        var envPath = envPaths[i];
        if (/npm(?:\\|\/)?$/.test(envPath)) {
            return envPath;
        }
    }

    return null;
}


/**
 * test wheter a path is directory
 *
 * @param {String} dpath
 *
 * @returns {Boolean}
 */
function isDirectory (dpath) {
    try {
        return fs.statSync(dpath).isDirectory();
    } catch (e) {
        return false;
    }
}

/**
 * copy file sync
 *
 * @param {String} src Srouce file
 * @param {String} dest Target file or directory path
 */
function copyFile (src, dest) {
    var srcBuffer = fs.readFileSync(src, { flag: 'r' });

    if (isDirectory(dest)) {
        var srcFileName = path.basename(src);
        dest = path.join(dest, srcFileName);
    }

    fs.writeFileSync(dest, srcBuffer, { flag: 'w' });
}

/**
 * copy content files and subdirectories recursively
 *
 * @param {String} src Source directory
 * @param {String} dest Target directory
 * @param {Boolean} mixin Don't create new directory
 */
function recursiveCopy (src, dest, mixin) {
    if (!mixin) {
        var srcDirName = path.basename(src);
        dest = path.join(dest, srcDirName);
        fs.mkdirSync(dest);
    }

    var entries = fs.readdirSync(src, { encoding: 'utf8' });
    entries.forEach(function (entry) {
        var entryPath = path.join(src, entry);
        if (isDirectory(entryPath)) {
            recursiveCopy(entryPath, dest, false);
        } else {
            copyFile(entryPath, dest);
        }
    });
}

/**
 * delete a directory recursively
 *
 * @param {String} dpath Directory to delte
 */
function recursiveDelete (dpath) {
    var entries = fs.readdirSync(dpath, { encoding: 'utf8' });
    entries.forEach(function (entry) {
        var entryPath = path.join(dpath, entry);
        if (isDirectory(entryPath)) {
            recursiveDelete(entryPath);
        } else {
            fs.unlinkSync(entryPath);
        }
    });

    fs.rmdirSync(dpath);
}


/**
 * write message to stderr and exit the process
 */
function errorLogAndExit () {
    console.error.apply(console, arguments);
    process.exit();
}


module.exports.getNpmPath = getNpmPath;
module.exports.copyFileSync = copyFile;
module.exports.recursiveCopy = recursiveCopy;
module.exports.recursiveDelete = recursiveDelete;
module.exports.errorLogAndExit = errorLogAndExit;
module.exports.isDirectory = isDirectory;