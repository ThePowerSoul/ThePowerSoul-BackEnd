const fs = require('fs');
const path = require('path');

const helper = require('./helper');
const isDirectory = helper.isDirectory;

function install (targetPath) {
    var nodeModuleDir = path.join(targetPath, 'node_modules');
    if (!isDirectory(nodeModuleDir)) {
        fs.mkdirSync(nodeModuleDir);
    }

    helper.recursiveCopy('./source/mini-server-core', nodeModuleDir, false);
    console.log("mini-server-core module installed");
    helper.recursiveCopy('./source/mini-server-cli', nodeModuleDir, false);
    console.log("mini-server-cli module installed");
    helper.recursiveCopy('./source/mini-server-plugins', nodeModuleDir, false);
    console.log("mini-server-plugins module installed");
    helper.copyFileSync('./source/miniserver.cmd', targetPath);
}

function checkNodePathEnv () {
    var npath = process.env['NODE_PATH'];
    if (!npath) {
        console.warn("You haven't setup 'NODE_PATH' environment viarable, this may cause errors when you're trying to import installed modules");
    }
}

function main (args) {
    var targetPath;
    if (args.length > 1) {
        helper.errorLogAndExit("Too much arguments");
    } else if (args.length === 1) {
        targetPath = args[0];
    } else {
        targetPath = helper.getNpmPath();
        if (targetPath === null) {
            helper.errorLogAndExit("Cannot find npm directory from environment variables");
        }
    }

    if (args.length === 0) {
        checkNodePathEnv();
    }

    if (!isDirectory(targetPath)) {
        helper.errorLogAndExit(targetPath + " is not a directory");
    } else {
        install(targetPath);
        console.log("Install mini-server success!");
    }
}

main(process.argv.slice(2));