const path = require('path');
const fs = require('fs');
const childProcess = require('child_process');

const miniServer = require('../mini-server-core');

var plugin;
try {
    plugin = require('../mini-server-plugins');
} catch (err) {
    plugin = null;
}


function errorLogAndExit () {
    console.error.apply(console, arguments);
    process.exit();
}

/**
 * @param {String} msg
 */
function warningLog (msg) {
    console.log(msg);
}

const DIR_STATE = {
    NORMAL: 0x01,
    NOTEXISTS: 0x02,
    NOTDIR: 0x03
};

/**
 * @param {!String} dirpath
 * @returns {DIR_STATE}
 */
function testDirectory (dirpath) {
    try {
        var stat = fs.statSync(dirpath);
        return stat.isDirectory() ? DIR_STATE.NORMAL : DIR_STATE.NOTDIR;
    } catch (e) {
        return DIR_STATE.NOTEXISTS;
    }
}

function showHelp () {
    process.stdout.write([
        'USAGE: miniserver [--profile] [--port] [--dir] [--doc] [itemspecs]',
        '',
        'Options:',
        '--profile          - whether to use profilers',
        '--port             - specify the port number',
        '--dir              - root directory of the server',
        '--config-dir       - directory for config file, use root directory if not given',
        '--doc              - show api document',
        '-h, --help         - display this help and exit',
        '-v, --version      - show the current version',
        '--upgrade-plugin   - upgrade plugin by given name',
        '--force            - upgrade plugin without checking version',
        'itemspecs          - server files',
        ''
    ].join('\n'));

    process.exit(-1);
}

function showVersion () {
    var packageFile = path.join(__dirname, 'package.json');
    var packageInfo = require(packageFile);
    process.stdout.write(packageInfo.version);
    process.stdout.write('\n');

    process.stdout.write("Core: " + miniServer.getVersion());
    process.stdout.write('\n');

    process.exit(0);
}

function showDocument (docFilePath) {
    var filename = path.basename(docFilePath);
    try {
        process.stdout.write("Loading document file: " + filename + " ...");
        childProcess.execSync('call "' + docFilePath + '"');
    } catch (err) {
        process.stdout.write("Loading document file: " + filename + " failed");
        process.stdout.write('\n');
        process.stdout.write(err.message);
    }

    process.stdout.write('\n');
    process.exit(-1);
}

function upgradePlugin (name, force) {
    var pluginManager = plugin.manager;
    var stateCodes = pluginManager.PACKAGE_STATE_CODES;

    process.stdout.write("Checking plugin repository...\n");
    pluginManager.upgradePackage(name, force)
        .then(function (history) {
            process.stdout.write("Plugin upgrade success.\n");
            if (history) {
                process.stdout.write(history.old + " -> " + history.new + "\n");
            }
        }, function (err) {
            switch (err.code) {
                case stateCodes.NOTFOUND:
                    process.stderr.write("Upgrade plugin failed: plugin not found");
                    break;
                case stateCodes.UPGRADED:
                    process.stdout.write("Plugin has already been upgraded: " + err.msg);
                    break;
                case stateCodes.UNKNOWN:
                    process.stderr.write("Upgrade plugin failed: \n" + err.msg);
                    break;
            }

            process.stdout.write('\n');
            process.exit(-1);
        });
}

/**
 * @param {Array<String>} args
 * @param {Number} defaultPort
 * @param {String} defaultPath
 */
function parseArgs (args, defaultPort, defaultPath) {
    var result = {
        doProfile: false,
        port: defaultPort,
        path: defaultPath,
        configPath: null,
        files: []
    };

    for (var i = 0; i < args.length; i++) {
        var param = args[i];

        switch (param) {
            case '--profile':
                result.doProfile = true;
                break;
            case '--port':
                var port = Number(args[i + 1]);
                if (isNaN(port)) {
                    errorLogAndExit("Invalid port: " + args[i + 1]);
                } else {
                    if (port < 0) {
                        errorLogAndExit("Invalid port number: " + port);
                    } else if (port === 0) {
                        result.port = 0;
                    } else if (port <= 1023) {
                        errorLogAndExit("Cannot listern to ports within 0 ~ 1023, which are well-known ports");
                    } else {
                        result.port = port;
                    }
                }

                i++;
                break;
            case '--dir':
                var directory = args[i + 1];
                if (directory && directory.length > 0) {
                    var abspath = path.resolve(directory);
                    var dirstate = testDirectory(abspath);
                    if (dirstate == DIR_STATE.NORMAL) {
                        result.path = abspath;
                    } else if (dirstate == DIR_STATE.NOTDIR) {
                        errorLogAndExit("The provided path is not a directory: " + abspath);
                    } else {
                        errorLogAndExit("The provided dirctory is not exists: " + abspath);
                    }
                } else {
                    errorLogAndExit("Directory is not provided");
                }

                i++;
                break;
            case '--config-dir':
                var confDirectory = args[i + 1];
                if (confDirectory && confDirectory.length > 0) {
                    var abspath = path.resolve(confDirectory);
                    var dirstate = testDirectory(abspath);
                    if (dirstate == DIR_STATE.NORMAL) {
                        result.configPath = abspath;
                    } else if (dirstate == DIR_STATE.NOTDIR) {
                        errorLogAndExit("The provided path is not a directory: " + abspath);
                    } else {
                        errorLogAndExit("The provided dirctory is not exists: " + abspath);
                    }
                }else{
                    errorLogAndExit("Config directory is not provided");
                }

                i++;
                break;
            case '-v':
            case '--version':
                showVersion();
                break;
            case '-h':
            case '--help':
                showHelp();
                break;
            case '--doc':
                var docName = args[i + 1];
                var docPath = miniServer.getDocPath(docName);
                if (docPath === null) {
                    errorLogAndExit("Cannot find document for module: " + docName);
                } else {
                    showDocument(docPath);
                }
                break;
            case '--upgrade-plugin':
                if (plugin === null) {
                    errorLogAndExit("Plugin module is not installed");
                } else {
                    var force, pluginName;
                    if (args[i + 1] == '--force') {
                        force = true;
                        pluginName = args[i + 2];
                    } else {
                        force = args.indexOf('--force', i + 2) >= 0;
                        pluginName = args[i + 1];
                    }

                    if (/^-/.test(pluginName)) {
                        errorLogAndExit("Invalid plugin name: " + pluginName);
                    } else {
                        upgradePlugin(pluginName, force);
                        return null;
                    }
                }
                break;
            default:
                // read item specs
                for (; i < args.length; i++) {
                    var spec = args[i];
                    if (spec.startsWith('-')) {
                        errorLogAndExit("Unknown parameter: " + spec);
                    }else{
                        result.files.push(spec);
                    }
                }

                break;
        }
    }

    if (result.configPath === null) {
        result.configPath = result.path;
    }

    return result;
}


module.exports.errorLogAndExit = errorLogAndExit;
module.exports.warningLog = warningLog;
module.exports.showHelp = showHelp;
module.exports.parseArgs = parseArgs;