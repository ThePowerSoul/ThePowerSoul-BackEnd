const fs = require('fs');
const path = require('path');

const chalk = require('chalk');

const miniServer = require('../mini-server-core');
const RuntimeCore = miniServer.RuntimeCore;
const cliUtil = require('./cli');


const PORT = 8080;                          // default socket
const PATH = process.cwd();                 // default directory
const USER_MODULE = 'MiniServerFile.js';    // default user module file


function fileExists(fpath) {
    try{
        return fs.statSync(fpath).isFile();
    }catch (e){
        return false;
    }
}


function reloadModule (modulePath) {
    var moduleCache = require.cache;
    var fullpath = require.resolve(modulePath);
    if (moduleCache.hasOwnProperty(fullpath)) {
        delete moduleCache[fullpath];
    }

    return require(modulePath);
}

function getUserModules (config) {
    // decide user modules
    var userFiles = config.files;
    if (userFiles.length === 0) {
        var defaultFile = path.join(config.configPath, USER_MODULE);
        if (fileExists(defaultFile)) {
            userFiles.push(defaultFile);
        } else {
            cliUtil.warningLog("Missing " + USER_MODULE);
        }
    } else {
        for (var i = 0; i < userFiles.length; i++) {
            var fpath = path.join(config.configPath, userFiles[i]);
            if (fileExists(fpath)) {
                userFiles[i] = fpath;
            } else {
                cliUtil.errorLogAndExit("File " + fpath + " is not exists");
            }
        }
    }

    return userFiles;
}

function loadUserModules (runtime, files) {
    files.forEach(function (moduleFile) {
        var userHandler = reloadModule(moduleFile);
        if (typeof userHandler == 'function') {
            // extend runtime by user handler
            userHandler(runtime);
        } else {
            throw new TypeError("User module must be function");
        }
    });
}

/**
 * convert error level to hinting
 */
function formatLogLevels (level) {
    if (!level){
        return '';
    }else{
        var prefix = '';
        for (var i = 0; i < level; i++) {
            prefix += '*';
        }

        return prefix;
    }
}

/**
 * @param {Date} time
 * @returns {String}
 */
function formatLogTime(time) {
    var hour = time.getHours(), minute = time.getMinutes(), second = time.getSeconds();
    if (hour < 10) {
        hour = '0' + hour;
    }
    if (minute < 10) {
        minute = '0' + minute;
    }
    if (second < 10) {
        second = '0' + second;
    }

    var timestamp = [hour, minute, second].join(':');
    return '[' + timestamp + ']';
}

/**
 * @param {Object} profileInfo
 * @returns {String}
 */
function formatProfileInfo (profileInfo) {
    var formatFrags = [];
    Object.keys(profileInfo).forEach(function (name) {
        switch (name) {
            case 'timing':
                formatFrags.push('took ' + profileInfo[name] + ' ms');
                break;
            case 'traffic':
                formatFrags.push('transfered ' + profileInfo[name] + ' bytes');
                break;
        }
    });

    return formatFrags.join(', ');
}

/**
 * @param {String} msg
 * @param {Number} level
 *
 * @returns {String}
 */
function highliteMsgByLevel (msg, level) {
    if (level > 0) {
        switch (level) {
            case 2:
                return chalk.yellow(msg);
            case 3:
                return chalk.red(msg);
            default:
                return msg;
        }
    } else{
        return msg;
    }
}

/**
 * cli logger message formatter
 */
function loggerFormat (message) {
    var parts = [];

    var timestamp;
    if (message.time) {
        timestamp = chalk.blue(formatLogTime(message.time));
    } else {
        timestamp = null;
    }

    var levels = formatLogLevels(message.level);
    if (levels.length > 0) {
        parts.push(levels);
    }

    parts.push(message.content, '\n');

    // profiler results
    var profileInfo = message.getAttr('profile');
    if (profileInfo) {
        var profileOutput = formatProfileInfo(profileInfo);
        if (profileOutput.length > 0) {
            parts.push('  ->', profileOutput, '\n');
        }
    }

    var mainMsg = highliteMsgByLevel(parts.join(' '), message.level);
    if (timestamp === null) {
        return mainMsg;
    } else {
        return [timestamp, mainMsg].join(' ');
    }
}

function createRuntime (config) {
    var runtime = new RuntimeCore(config.path, config.doProfile, config.port);
    runtime.useProfilers('timing', 'traffic');
    runtime.logger.setMessageTransformer(loggerFormat);
    return runtime;
}

function main (args) {
    var params = cliUtil.parseArgs(args, PORT, PATH);

    if (params === null) {
        return;
    }

    // decide user modules
    var userFiles = getUserModules(params);

    // create runtime
    var runtime = createRuntime(params);

    // load user modules
    loadUserModules(runtime, userFiles);

    // create server
    var server = miniServer.createServer(runtime, function () {
        var address = server.getAddress();
        runtime.writeLog("Server started, running at port " + address.port + "...");
    });

    /**
     * command interface
     */
    function closeCurrentServer (callback) {
        if (server) {
            server.close(callback);
            server = null;
        } else {
            if (typeof callback == 'function') {
                callback();
            }
        }
    }

    var readline = require('readline');
    const serverInterface = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    serverInterface.on('line', function (msg) {
        msg = msg.trim();
        switch (msg){
            case 'restart':
                // runtime dispose
                runtime.dispose();
                // close server
                closeCurrentServer(function (err) {
                    if (err) {
                        cliUtil.errorLogAndExit("Close current server failed");
                    } else {
                        // create new runtime
                        runtime = createRuntime(params);
                        // reload user modules
                        loadUserModules(runtime, userFiles);
                        // create new server
                        server = miniServer.createServer(runtime, function () {
                            runtime.writeLog("restart server success ...");
                        });
                    }
                });
                break;
            case 'exit':
                closeCurrentServer(process.exit);
                break;
            case 'clear':
                console.log('\u001b[2J\u001b[0;0H');
                break;
            default:
                console.log('Unknown command: ' + msg);
                return;
        }
    });

    serverInterface.on('SIGINT', function () {
        closeCurrentServer();
        process.exit();
    });
}


// entry
main(process.argv.slice(2));