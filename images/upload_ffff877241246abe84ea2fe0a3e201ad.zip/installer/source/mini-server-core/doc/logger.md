Logger
==========

## methods

`addFilter(filter : RegExp | Function)`

添加一个logger过滤器，过滤器可以是一个正则表达式或函数（返回布尔值），被过滤器检测为true的消息不会在命令行输出

`setStream(stream : Writable, closeOldStream : Boolean = false)`

指定日志的输出流，输出流默认为`process.stdout`
  * stream: 自定义的输出流，必须为一个 *writable* 对象，即必须实现`write(Object)`方法
  * closeOldStream: 是否关闭已有的输出流，如果当前的输出流支持`close()`方法，则会自动进行调用

`setMessageTransformer(tansformer : Function)`

注册一个消息转换器，该方法属于编程接口，一般不会使用

`enableTimestamp()`

在每条输出前增加时间戳