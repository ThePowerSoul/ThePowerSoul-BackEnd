ProxyHandler
==========

## methods
`overrideHeader(header : String, value : String) -> this`

添加一对请求头，如果value为null，表示移除原始请求中的相应报头

`overrideHeaders(headers : Object) -> this`

添加一组请求头

`useUrlTransformer(transformer : Function) -> this`

添加一个url转换函数，用于对目标请求url进行配置，该函数有如下参数：
  * urlInfo: [UrlConstructor](./url-constructor.html)对象，默认配置为defaultUrl(如果defaultUrl带有模板字符串，则预先经过处理)
  * rawUrlInfo: 原始请求url解析后的对象，包含以下属性
    * pathname: 请求路径
    * queryParams: 一个键值对，通过解析url上query string部分得到
  * parts: url匹配捕获结果

  ```javascript
  handler.setUrlTransformer(function (urlInfo, rawUrlInfo, parts) {
      switch (parts[0]) {
          case 'baidu':
              urlInfo.setPathname('www.baidu.com');
              return urlInfo;
          case 'google':
              urlInfo.setPathname('www.google.com');
              return urlInfo;
          default:
              return urlInfo;
      }
  });
  ```

`useBodyTransformer(transformer : Function) -> this`

*暂不支持*

`setTimeout(timeout : Number) -> this`

设置该请求的超时时间，该配置会覆盖[runtime](./runtime.html)的全局代理请求超时配置