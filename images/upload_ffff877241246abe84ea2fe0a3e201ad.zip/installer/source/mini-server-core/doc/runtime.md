Runtime
==========

## properties
`logger`

获取一个和runtime绑定的[日志对象](./logger.html)


## methods
`registerEXHandler(method : String, matcher : (String|RegExp), handler : Function) -> EXHandler`

注册一个通用请求处理句柄
  * method: http 请求方法
  * matcher: url匹配器，可以使用字符串(完全匹配)和正则表达式
  * handler: 请求处理函数
  * 返回值：EXHandler对象

    handler参数为：
    * urlInfo: 解码后的请求路由对象
    * headers: 请求头
    * body: 请求体，如果没有请求体为null
    * matchers: 如果url匹配器为正则表达式，该参数为捕获组列表
    * asyncHandler: 异步完成执行句柄，如果回调内带有异步操作，可以直接返回null，然后通过该函数结束请求

    起返回值为一个对象，需包含以下属性：
    * code: http状态码
    * headers: 响应头
    * data: 响应体
    * timeout: 响应延迟，用于模拟耗时请求

`registerProxyHandler(method : String, matcher : (String|RegExp|Array<RegExp>), defaultUrl : String) -> ProxyHandler`

注册一个代理(转发)请求
  * method: http 请求方法
  * matcher: url匹配器，可以使用字符串(完全匹配)、正则表达式或正则表达式数组
  * defaultUrl: 转发请求的默认url，不可省略，支持模板字符串
  * 返回值：[ProxyHandler](./proxy-handler.html)对象

`setProxyTimeout(timeout : Number)`

设置转发请求的超时(毫秒)，默认为0(不超时)

`setProxyHeaders(headers : Object, matchVal : RegExp)`

设置全局的代理请求报头
  * headers: 表示header的键值对
  * matchVal: 可选，用来和转发目标的url进行匹配决定是否添加这组header，如果存在和全局header重合的字段，会覆盖之

```javascript
// 给所有代理请求都添加Cookie
handler.setProxyHeaders({
    'Cookie': 'Token=213456'
});

// 只给对192.168.41.87的请求添加author头
handler.setProxyHeaders({
  'Author': 'Anonymous'
}, /192\.168\.41\.87/);
```

`setVirtualDirectory(urlMask : String, fsPath : String)`

添加一个虚目录
  * urlMask: url掩码，第一个字符必须是'/'，查找路径时会从url的起始出开始匹配
  * fsPath: 文件系统中目录路径，可以指定其他盘符中的目录，建议使用绝对路径

`setProxyServer(serverInfo : Object)`

设置转发请求的代理服务器，参数为代理服务器配置，有如下配置项：
  * protocol: 可选，代理服务器通信协议，默认为http
  * host: 代理服务器主机名或IP地址
  * port: 可选，代理服务器端口

```javascript
// 使用本机8888端口进行代理(Fiddle)
handler.setProxyServer({
    host: '127.0.0.1',
    port: 8888
});
```
