UrlConstructor
==========

## methods
`setProtocol(protocol : String) -> this`

设置url的协议，如 'http'

`setHostname(hostname : String) -> this`

设置设置主机名(不包括端口号)，如 'www.lindge.com'

`setPort(numPort : Number) -> this`

设置端口号，端口号必须为介于(0, 65535]之间的整数

`setPathname(pathname : String) -> this`

设置请求路径，不包含*querystring*部分

`getQueryParams() -> Object`

获取代表*querystring*参数的键值对

`setQueryParams(params : Object) -> this`

设置*querystring*参数

`removeQueryParams(param : String) -> this`

移除一个*querystring*参数

`clearQueryParams() -> this`

移除所有*querystring*参数

`getUrlObject() -> Object`

获取一个url对象，包含如下属性：
  * protocol: 协议名,
  * hostname: 主机名,
  * port: 端口号,
  * host: 主机全名(hostname:port),
  * pathname: 请求路径,
  * search：querystring部分的字符串
  * path: 完整url


## properties
`path`

只读，完整url

`host`

只读，获取主机全名