module.exports.MIME_TABLE = require('./lib/mime-types');
module.exports.HTTP_STATUS_CODE = require('./lib/http/status-code');
module.exports.HTTP_METHODS = require('./lib/http/methods');
module.exports.LOG_ERR_LEVEL = require('./lib/logger/levels');


module.exports.encodeJSON = require('./lib/encoding').encodeJSON;
module.exports.getDecoder = require('./lib/encoding').getDecoder;


module.exports.RuntimeCore = require('./lib/runtime').RuntimeCore;
module.exports.createServer = require('./lib/server').createServer;


module.exports.DEFAULT_TEXT_ENCODING = require('./lib/encoding').DEFAULT_TEXT_ENCODING;


const fs = require('fs');
const path = require('path');

const env = require('./lib/_env');
const assemble = require('./lib/assemble');

/**
 * @param {String} docName
 * @returns {?String}
 */
module.exports.getDocPath = function (docName) {
    var docPath = path.join(env.DOC_DIR, docName + '.html');
    try{
        if (fs.statSync(docPath).isFile()) {
            return docPath;
        } else {
            return null;
        }
    } catch(e) {
        return null;
    }
};

/**
 * @returns {String}
 */
module.exports.getVersion = function () {
    return assemble.Version;
};