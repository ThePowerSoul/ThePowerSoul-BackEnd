const PLUGIN_CACHE = {};

/**
 * @param {String} name
 */
function addPluginToCache (name) {
    if (PLUGIN_CACHE.hasOwnProperty(name)) {
        return PLUGIN_CACHE[name];
    } else {
        var pluginInfo = {
            fn: null,
            info: null
        };

        PLUGIN_CACHE[name] = pluginInfo;
        return pluginInfo;
    }
}


module.exports.PLUGIN_CACHE = PLUGIN_CACHE;
module.exports.add = addPluginToCache;