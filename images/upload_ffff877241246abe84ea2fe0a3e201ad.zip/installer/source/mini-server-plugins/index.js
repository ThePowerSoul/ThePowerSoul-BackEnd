const PluginBase = require('./pluginbase');
const errors = require('./pluginerrors');

module.exports.PluginBase = PluginBase;
module.exports.PluginLoadError = errors.PluginLoadError;


const path = require('path');

const cache = require('./cache');
const lib = require('./lib');
const manager = require('./manager');


const REPOS = [path.resolve(path.join(__dirname, 'repository'))];

const SINGLETONS = {};
const PLUGIN_CACHE = cache.PLUGIN_CACHE;


/**
 * get the storage path of the plugin name
 *
 * @param {String} name  name of the plugin
 * @returns {?String} full path of the plugin package, null if plugin is not found
 */
function locatePlugin(name) {
    for (let repo of REPOS) {
        var package = path.join(repo, name);
        if (lib.isDirectory(package)) {
            return package;
        }
    }

    return null;
}

/**
 * load and valid a plugin by name from the builtin repository
 *
 * @param {String} pluginName  name of the plugin
 * @returns {Function} the plugin constructor
 *
 * @throws {PluginLoadError}
 */
function loadPluginFromRepo(pluginName) {
    var pluginPath = locatePlugin(pluginName);

    if (pluginPath === null) {
        throw new errors.PluginNotFoundError("Plugin: " + pluginName + " is not found");
    } else if (!lib.isFile(path.join(pluginPath, 'package.json'))) {
        throw new errors.PluginBrokenError("Plugin: " + pluginName + " is broken");
    } else {
        var pluginFn = require(pluginPath);
        if (typeof pluginFn == 'function') {
            return pluginFn;
        } else {
            throw new errors.PluginInitializeError("Plugin: " + pluginName + " was not initialized properly");
        }
    }
}


/**
 * find and create an instance of plugin
 *
 * @param {String} pluginName name of the plugin
 * @param {...String} params initialization arguments
 *
 * @returns {PluginBase}
 */
function loadPlugin(pluginName, ...params) {
    if (typeof pluginName != 'string' || pluginName.length < 1) {
        throw new Error("Invalid plugin name");
    }

    var pluginFn;
    if (PLUGIN_CACHE.hasOwnProperty(pluginName)) {
        pluginFn = PLUGIN_CACHE[pluginName].fn;
    } else {
        pluginFn = loadPluginFromRepo(pluginName);
        cache.add(pluginName).fn = pluginFn;
    }

    return new pluginFn(...params);
}

/**
 * find and create a singleton instance of plugin
 *
 * @param {String} pluginName name of the plugin
 * @param {...String} params initialization arguments
 *
 * @returns {PluginBase}
 */
function loadPluginSingleton(pluginName, ...params) {
    var singleton = SINGLETONS[pluginName];
    if (singleton) {
        return singleton;
    } else {
        singleton = loadPlugin(pluginName, ...params);
        SINGLETONS[pluginName] = singleton;
        return singleton;
    }
}

/**
 * add a new directory to search for plugin
 *
 * @param {String} pluginPath  directory path
 */
function addSearchPath (pluginPath) {
    if (lib.isDirectory(pluginPath)) {
        REPOS.unshift(path.resolve(pluginPath));
    } else {
        throw new Error("Plugin path: " + pluginPath + " is not exists");
    }
}


module.exports.load = loadPlugin;
module.exports.loadSingleton = loadPluginSingleton;
module.exports.addSearchPath = addSearchPath;
module.exports.manager = manager;