const fs = require('fs');
const path = require('path');
const constants = require('constants');

const nodezip = require('node-zip');


/**
 * detect whether file exists
 *
 * @param  {String} fpath file path
 * @returns {Boolean}
 */
function isFile(fpath) {
    try {
        return fs.statSync(fpath).isFile();
    } catch (e) {
        return false;
    }
}

/**
 * detect whether the given path is directory
 *
 * @param {String} dpath
 * @returns {Boolean}
 */
function isDirectory(dpath) {
    try {
        return fs.statSync(dpath).isDirectory();
    } catch (e) {
        return false;
    }
}

/**
 * @param {Response} response
 * @return {Boolean}
 */
function isResponseSuccess (response) {
    return response.statusCode < 400;
}

/**
 * @param {Response} response
 * @return {Promise<Buffer>}
 */
function readResponseBody (response) {
    var buffers = [];
    var bufferLen = 0;

    var promise = new Promise(function (resolve, reject) {
        response.on('data', (data) => {
            buffers.push(data);
            bufferLen += data.length;
        });

        response.on('end', () => {
            if (bufferLen > 0) {
                var totalBuffer = Buffer.concat(buffers, bufferLen);
                resolve(totalBuffer);
            } else {
                resolve(null);
            }
        });

        response.on('error', reject);
    });

    return promise;
}

/**
 * unzip zip stream to the target directory
 *
 * @param {Buffer} zipstream  stream of zip file
 * @param {String} target   target directory
 */
function unzipStream(zipstream, target) {
    if (!Buffer.isBuffer(zipstream)) {
        throw new TypeError("zipstream must be buffer");
    }

    if (!isDirectory(target)) {
        fs.mkdirSync(target);
    }

    var zipdata = nodezip(zipstream, { base64: false, checkCRC32: true });
    var contents = zipdata.files;

    Object.keys(contents).forEach(key => {
        var itemInfo = contents[key];
        var fullpath = path.join(target, itemInfo.name);

        if (itemInfo.dir) {
            fs.mkdirSync(fullpath);
        } else {
            var flags = constants.O_WRONLY | constants.O_CREAT | constants.O_SYNC | constants.O_TRUNC;
            var fd = fs.openSync(fullpath, flags);

            try {
                var filedata = itemInfo.asNodeBuffer();
                fs.writeSync(fd, filedata);
            } finally {
                fs.closeSync(fd);
            }
        }
    });
}

/**
 * unzip zip archive contents to the target directory
 *
 * @param {String} zipfile  path of the zip file
 * @param {String} target   target directory
 */
function unzipFile(zipfile, target) {
    if (!isFile(zipfile)) {
        throw new Error(`file ${zipfile} is not exists`);
    }

    var zipstream = fs.readFileSync(zipfile);
    unzipStream(zipstream, target);
}

/**
 * remove a directory recursively
 *
 * @param {String} dpath Directory to delte
 */
function removeDirectory (dpath) {
    if (isDirectory(dpath)) {
        var entries = fs.readdirSync(dpath, { encoding: 'utf8' });
        entries.forEach(function (entry) {
            var entryPath = path.join(dpath, entry);
            if (isDirectory(entryPath)) {
                removeDirectory(entryPath);
            } else {
                fs.unlinkSync(entryPath);
            }
        });

        fs.rmdirSync(dpath);
    } else {
        throw new Error(`Directory ${dpath} is not exists`);
    }
}


module.exports.isFile = isFile;
module.exports.isDirectory = isDirectory;
module.exports.isResponseSuccess = isResponseSuccess;
module.exports.readResponseBody = readResponseBody;
module.exports.unzipStream = unzipStream;
module.exports.unzipFile = unzipFile;
module.exports.removeDirectory = removeDirectory;