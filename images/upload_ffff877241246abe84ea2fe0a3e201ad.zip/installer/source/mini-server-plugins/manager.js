const fs = require('fs');
const path = require('path');
const http = require('http');

const cache = require('./cache');
const lib = require('./lib');

const PLUGIN_CACHE = cache.PLUGIN_CACHE;
const REPOS = [path.resolve(path.join(__dirname, 'repository'))];


const PLUGIN_INFO_FIELDS = ['version', 'description', 'author'];
const PACKAGE_SERVICE_HOST = '192.168.15.166';
const PACKAGE_SERVICE_PORT = 80;
const PACKAGE_SERVICE_ROOT = '/Doc/dev/environment/plugins';

const PACKAGE_STATE_CODES = {
    NOTFOUND: 0x02,
    UPGRADED: 0x04,
    UNKNOWN: 0x03
};


/**
 * @param {String} pluginPath
 * @returns {Object}
 */
function loadPluginInfo (pluginName, pluginPath) {
    var packageFile = path.join(pluginPath, 'package.json');
    var packageInfo = require(packageFile);

    var result = { name: pluginName };
    for (let field of PLUGIN_INFO_FIELDS) {
        result[field] = packageInfo[field] || '';
    }

    return result;
}

/**
 * @param {String} pluginName
 * @return {[String, Object]}
 */
function findPlugin (pluginName) {
    for (let repo of REPOS) {
        let pkgDir = path.join(repo, pluginName);
        let pluginPkgFile = path.join(pkgDir, 'package.json');

        if (lib.isFile(pluginPkgFile)) {
            return [pkgDir, require(pluginPkgFile)];
        }
    }

    return null;
}

/**
 * list all valided plugins found in the repositories
 *
 * @returns {Object}
 */
function listPlugins () {
    var pluginList = [];

    for (let repo of REPOS) {
        for (let item of fs.readdirSync(repo)) {
            let itemPath = path.join(repo, item);
            if (lib.isDirectory(itemPath) && lib.isFile(path.join(itemPath, 'package.json'))) {
                if (PLUGIN_CACHE.hasOwnProperty(item)) {
                    pluginList.push(PLUGIN_CACHE[item].info);
                } else {
                    // load plugin fn
                    let pluginFn = require(itemPath);
                    if (typeof pluginFn == 'function') {
                        let pluginInfo = cache.add(item);
                        pluginInfo.fn = pluginFn;
                        pluginInfo.info = loadPluginInfo(item, itemPath);
                        pluginList.push(pluginInfo.info);
                    }
                }
            }
        }
    }

    return pluginList.sort((v1, v2) => {
        var n1 = v1.name, n2 = v2.name;
        if (n1 == n2) {
            return 0;
        } else if (n1 < n2) {
            return -1;
        } else {
            return 1;
        }
    });
}


/**
 * @param {String[]?} ids
 * @return {Promise<Map<String, String>>}
 */
function checkPluginVersion (ids) {
    var queryNames;
    if (!ids) {
        queryNames = '*';
    } else if (Array.isArray(ids)) {
        queryNames = encodeURIComponent(ids.join(','));
    } else {
        throw new TypeError("ids must be array");
    }

    var promise = new Promise((resolve, reject) => {
        var req = http.request({
            protocol: 'http:',
            hostname: PACKAGE_SERVICE_HOST,
            port: PACKAGE_SERVICE_PORT,
            path: `${PACKAGE_SERVICE_ROOT}/api/Packages?packageNameQuery=${queryNames}`,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 0
        }, res => {
            lib.readResponseBody(res)
                .then(buf => {
                    var data = buf.toString('utf8');
                    if (lib.isResponseSuccess(res)) {
                        resolve(JSON.parse(data));
                    } else {
                        reject(`${res.statusCode}: ${data}`);
                    }
                }, reject);
        });

        req.on('error', reject);
        req.end();
    });

    return promise;
}

/**
 * @param {String} left
 * @param {String} right
 *
 * @return {Boolean}  1: left > right; -1: left < right; 0: left == right
 */
function compareVersion (left, right) {
    var leftParts = left.split('.');
    var rightParts = right.split('.');

    for (let i = 0; i < 3; i++) {
        var leftNum = parseInt(leftParts[i]);
        var rightNum = parseInt(rightParts[i]);

        if (leftNum != rightNum) {
            return leftNum > rightNum ? 1 : -1;
        }
    }

    return 0;
}

/**
 * @param {String} id  package id
 * @param {Boolean=} force  force upgrading, doesn't check version
 */
function upgradePackage (id, force) {
    function UpgradeResult (code, msg) {
        this.code = code;
        this.msg = null;

        if (arguments.length > 1) {
            this.msg = msg;
        }
    }

    function downloadStream (target) {
        var pkgId = encodeURIComponent(id);
        var promise = new Promise((resolve, reject) => {
            var req = http.request({
                protocol: 'http:',
                hostname: PACKAGE_SERVICE_HOST,
                port: PACKAGE_SERVICE_PORT,
                path: `${PACKAGE_SERVICE_ROOT}/api/PackageDownload?packageId=${pkgId}`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/octet-stream',
                    'Connection': 'Keep-Alive'
                },
                timeout: 0
            }, res => {
                lib.readResponseBody(res)
                    .then(buf => {
                        if (lib.isResponseSuccess(res)) {
                            if (!target) {
                                // use main repo if not given
                                target = path.join(REPOS[0], id);
                            }

                            if (lib.isDirectory(target)) {
                                lib.removeDirectory(target);
                            }

                            lib.unzipStream(buf, target);
                            resolve();
                        } else {
                            var data = buf.toString('utf8');
                            var msg = `${res.statusCode}: ${data}`;
                            if (res.statusCode == 404) {
                                reject(new UpgradeResult(PACKAGE_STATE_CODES.NOTFOUND, msg));
                            } else {
                                reject(new UpgradeResult(PACKAGE_STATE_CODES.UNKNOWN, msg));
                            }
                        }
                    }, reject);
            });

            req.on('error', err => reject(new UpgradeResult(PACKAGE_STATE_CODES.UNKNOWN, err)));
            req.end();
        });

        return promise;
    }

    if (typeof id != 'string' || id.length === 0) {
        throw new Error("Invalid id");
    }

    var pluginInfo = findPlugin(id);
    var pluginDir, version;
    if (pluginInfo) {
        pluginDir = pluginInfo[0];
        version = pluginInfo[1]['version'];
    } else {
        pluginDir = null;
        version = null;
    }

    var promise = new Promise((resolve, reject) => {
        if (force) {
            downloadStream(pluginDir).then(() => resolve(), reject);
        } else {
            checkPluginVersion([id])
                .then(mapping => {
                    var newVersion = mapping[id];
                    if (newVersion) {
                        if (version && compareVersion(newVersion, version) <= 0) {
                            reject(new UpgradeResult(PACKAGE_STATE_CODES.UPGRADED, version));
                        } else {
                            downloadStream(pluginDir).then(() => resolve({ old: version, new: newVersion }), reject);
                        }
                    } else {
                        reject(new UpgradeResult(PACKAGE_STATE_CODES.NOTFOUND));
                    }
                }, err => reject(new UpgradeResult(PACKAGE_STATE_CODES.UNKNOWN, err)));
        }
    });

    return promise;
}


module.exports.listPlugins = listPlugins;
module.exports.upgradePackage = upgradePackage;
module.exports.PACKAGE_STATE_CODES = PACKAGE_STATE_CODES;