const miniserver = require('../mini-server-core');
const RuntimeCore = miniserver.RuntimeCore;


/**
 * abstract base class for plugins
 *
 * @param {String} name  name of the plugin
 *
 * @constructor
 * @abstract
 */
function PluginBase (name) {
    this._validName(name);
    this._pluginName = name;
}

PluginBase.prototype._validName = function(name) {
    if (typeof name != 'string') {
        throw new TypeError("Plugin name must be string");
    }

    if (name.length < 1) {
        throw new Error("Name cannot be empty");
    }
};

/**
 * active the plugin by runtime object
 *
 * @param {RuntimeCore} runtime  the runtime object
 * @returns {PluginBase}
 */
PluginBase.prototype.active = function(runtime) {
    throw new Error("Cannot call abstract method: active(RuntimeCore)");
};


module.exports = PluginBase;