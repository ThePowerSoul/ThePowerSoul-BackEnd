const util = require('util');

/**
 * error for plugin loading
 */
function PluginLoadError (msg) {
    Error.call(this);
    this.message = msg;
}

util.inherits(PluginLoadError, Error);


/**
 * error when plugin cannot be found
 */
function PluginNotFoundError (msg) {
    PluginLoadError.call(this, msg);
}

util.inherits(PluginNotFoundError, PluginLoadError);


/**
 * error when the plugin structure is broken
 */
function PluginBrokenError (msg) {
    PluginLoadError.call(this, msg);
}

util.inherits(PluginBrokenError, PluginLoadError);


/**
 * error when plugin initialization is invalid
 */
function PluginInitializeError (msg) {
    PluginLoadError.call(this, msg);
}

util.inherits(PluginInitializeError, PluginLoadError);


module.exports.PluginLoadError = PluginLoadError;
module.exports.PluginNotFoundError = PluginNotFoundError;
module.exports.PluginBrokenError = PluginBrokenError;
module.exports.PluginInitializeError = PluginInitializeError;