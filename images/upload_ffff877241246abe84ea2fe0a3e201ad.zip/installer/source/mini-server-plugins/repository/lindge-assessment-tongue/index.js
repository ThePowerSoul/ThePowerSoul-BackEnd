const path = require('path');
const fs = require('fs');
const util = require('util');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


/**
 * @param {String} fpath  file path
 * @returns {Boolean}
 */
function isFile (fpath) {
    try {
        return fs.statSync(fpath).isFile();
    } catch (err) {
        return false;
    }
}


function LindgeAssessmentTounguePlugin () {
    PluginBase.call(this, 'lindge-assessment-tongue');

    this._realService = false;
    this._readServiceUrl = 'http://127.0.0.1:9700/api';

    this._storageRoot = null;

    this._cache = {
        'en.word.score': null,
        'en.sent.score': null,
        'en.pred.score': null
    };

    this._coreInfo = {
        // 内核版本号
        'version': '0.0.xx',
        // 内核资源版本号
        'res': 'eng.wrd.strap.x.y'
    };
}

util.inherits(LindgeAssessmentTounguePlugin, PluginBase);

LindgeAssessmentTounguePlugin.prototype.setStorageRoot = function(root) {
    if (typeof root == 'string' && root.length > 0) {
        this._storageRoot = path.resolve(root);
    } else {
        throw new Error("Invalid storage root");
    }

    return this;
};

LindgeAssessmentTounguePlugin.prototype.useRealService = function() {
    this._realService = true;
    return this;
};

LindgeAssessmentTounguePlugin.prototype.active = function(runtime) {
    if (this._storageRoot === null) {
        throw new Error("Storage root is not set");
    }

    var errorResponse = {
        code: HTTP_STATUS_CODE.badRequest
    };

    var missingCfgResponse = {
        code: HTTP_STATUS_CODE.badRequest
    };

    var evaluationErrorResponse = {
        code: HTTP_STATUS_CODE.internalServerError
    };

    var noEngineErrorResponse = {
        code: HTTP_STATUS_CODE.notFound
    };

    var cache = this._cache;
    var coreInfo = this._coreInfo;
    var storageRoot = this._storageRoot;

    function loadCfgByCoreType (type) {
        var cfgFile = path.join(storageRoot, type + '.json');
        if (isFile(cfgFile)) {
            var content = fs.readFileSync(cfgFile, { flag: 'r', encoding: miniserver.DEFAULT_TEXT_ENCODING });
            var cfg = JSON.parse(content);
            cache[type] = cfg;

            return cfg;
        } else {
            return null;
        }
    }

    runtime.registerEXHandler(HTTP_METHODS.POST, /^\/api\/Evaluation\/([a-z.]+)\/([0-9]+)\/([0-9]+)\/([0-9]+)/i,
    function (urlInfo, headers, body, parts) {
        if (!body.RefText || !body.BaseStream) {
            return evaluationErrorResponse;
        }

        var coreType = parts[0];
        if (cache.hasOwnProperty(coreType)) {
            var cfg = cache[coreType];
            if (cfg === null) {
                cfg = loadCfgByCoreType(coreType);
            }

            if (cfg !== null) {
                var result = cfg[body.RefText];
                if (typeof result == 'number' || typeof result == 'string') {
                    switch (parseInt(result)) {
                        case 404:
                            return noEngineErrorResponse;
                        case 500:
                            return evaluationErrorResponse;
                        default:
                            return errorResponse;
                    }
                } else if (result === undefined) {
                    return {
                        code: 551
                    };
                } else {
                    var evalInfo = {
                        version: coreInfo['version'],
                        res: coreInfo['range']
                    };

                    Object.keys(result).forEach(function (attr) {
                        evalInfo[attr] = result[attr];
                    });

                    var resInfo = {};
                    resInfo.result = evalInfo;

                    var bufferData = miniserver.encodeJSON(resInfo);

                    return {
                        code: HTTP_STATUS_CODE.success,
                        headers: {
                            'Content-Type': 'application/json',
                            'Content-Length': bufferData.length
                        },
                        data: bufferData
                    };
                }
            } else {
                return missingCfgResponse;
            }
        } else {
            return errorResponse;
        }
    });

    runtime.registerEXHandler(HTTP_METHODS.GET, /^\/api\/Evaluation/i,
    function () {
        return {
            code: HTTP_STATUS_CODE.success
        };
    });

    return this;
};


module.exports = LindgeAssessmentTounguePlugin;