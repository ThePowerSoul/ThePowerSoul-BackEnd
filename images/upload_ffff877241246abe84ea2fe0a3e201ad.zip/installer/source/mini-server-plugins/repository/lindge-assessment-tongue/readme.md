#### lindge-assessment-tongue

模拟驰声本地语言评测服务。

*使用前请先将路由表中 `assessment_tongue` 配置为 `/api`*

__方法__

`setStorageRoot(root: String) -> this`

指定配置文件存储根目录

__配置__

请求的url组成为：`/api/Evaluation/{coreType}/{sampleRate}/{bitrate}/{numChannels}`；
其中*coreType*可选的有：

* en.word.score
* en.sent.score
* en.pred.exam

如果url参数中的类型不再上述列表中，会返回400。

请求体包含`RefText`和`BaseStream`属性，这两个属性中任意一个为空会返回500。

如果请求没有其他问题，会到存储更目录中加载文件名和coreType相同的json文件，并根据其中和`RefText`匹配的配置项返回评分结果。

配置文件示例如下：

```javascript
{
    "past": {
        // 入参里指定的评分等级
        "rank": 100,
        // 录音时间,单位为毫秒
        "wavetime": 3400,
        // 评分耗时,单位为毫秒
        "systime": 1149,
        // 单词得分总分
        "overall": 82,
        // 每个音节详细得分
        "details": [
            {
                "char": "past",
                "dur": 540,
                "phone": [
                    {
                        "char": "p",
                        "score": 54
                    },
                    {
                        "char": "a",
                        "score": 100
                    },
                    {
                        "char": "s",
                        "score": 76
                    },
                    {
                        "char": "t",
                        "score": 94
                    }
                ]
            }
        ]
    },
    "error": 404,
    "not found": 500
}
```

如果希望返回特定的错误，可以直接将配置项设为错误码。