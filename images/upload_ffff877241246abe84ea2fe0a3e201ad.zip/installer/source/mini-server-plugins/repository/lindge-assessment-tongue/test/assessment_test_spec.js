const path = require('path');
const fs = require('fs');

var assessmentPlugin = require('../index.js');

const miniserver = require('mini-server-core');
const HTTP_METHODS = miniserver.HTTP_METHODS;
const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const MIME_TABLE = miniserver.MIME_TABLE;


describe("test assessment tongue", function () {
    var root = path.join(__dirname, './resource');
    var plugin;
    beforeEach(function () {
        plugin = new assessmentPlugin();
        plugin.setStorageRoot(root);
    });

    function createMockRuntime () {
        return {
            handlers: [],
            registerEXHandler: function (method, matcher, handler) {
                this.handlers.push({
                    method: method,
                    matcher: matcher,
                    handler: handler
                });
            }
        };
    }

    it("test assessment", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handler = mockRuntime.handlers[0];

        expect(handler.method).toBe(HTTP_METHODS.POST);
        expect(handler.matcher.test('/api/Evaluation/en.word.score/14400/16/2')).toBe(true);
        expect(handler.matcher.test('/api/Evaluation/en.word.score/14400/16')).toBe(false);

        var parts_1 = handler.matcher.exec('/api/Evaluation/en.word.score/14400/16/2').slice(1);
        var result_1 = handler.handler(null, {}, {
            RefText: "past",
            "BaseStream": "xxxx"
        }, parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);

        var fileContent = fs.readFileSync(path.join(root, 'en.word.score.json'), miniserver.DEFAULT_TEXT_ENCODING);
        var cfg = JSON.parse(fileContent);

        var requestData = result_1.data.toString(miniserver.DEFAULT_TEXT_ENCODING);
        expect(JSON.parse(requestData)['result']).toEqual(jasmine.objectContaining(requestData['past']));
    });

    it("test invalid evalaution type", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handler = mockRuntime.handlers[0];
        var parts_1 = handler.matcher.exec('/api/Evaluation/en.word.unknown/14400/16/2').slice(1);
        var result_1 = handler.handler(null, {}, {
            RefText: "past",
            "BaseStream": "xxxx"
        }, parts_1);

        expect(result_1.code).toBe(HTTP_STATUS_CODE.badRequest);
    });

    it("test invalid body", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handler = mockRuntime.handlers[0];
        var parts_1 = handler.matcher.exec('/api/Evaluation/en.word.score/14400/16/2').slice(1);
        var result_1 = handler.handler(null, {}, {
            RefText: "",
            "BaseStream": ""
        }, parts_1);

        expect(result_1.code).toBe(HTTP_STATUS_CODE.internalServerError);
    });

    it("test error config", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handler = mockRuntime.handlers[0];
        var parts_1 = handler.matcher.exec('/api/Evaluation/en.word.score/14400/16/2').slice(1);
        var result_1 = handler.handler(null, {}, {
            RefText: "error",
            "BaseStream": "xxxx"
        }, parts_1);

        expect(result_1.code).toBe(HTTP_STATUS_CODE.notFound);
    });
});