const fs = require('fs');
const path = require('path');
const util = require('util');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;

const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;
const MIME_TABLE = miniserver.MIME_TABLE;


/**
 * test whether the given path is a file
 *
 * @param {String} fpath
 * @returns {Boolean}
 */
function fileExists (fpath) {
    try {
        return fs.statSync(fpath).isFile();
    } catch (e) {
        return false;
    }
}

/**
 * test whether the given directory exists
 *
 * @param {String} dir
 * @returns {Boolean}
 */
function dirExists (dir) {
    try {
        return fs.statSync(dir).isDirectory();
    } catch (e) {
        return false;
    }
}

/**
 * @param {String} fname
 * @returns {String}
 */
function extractFileName (fname) {
    return path.basename(fname, path.extname(fname));
}

/**
 * @param {String} dir  path for search directory
 * @param {String} name  base name of the file to search
 *
 * @returns {?String}
 */
function findByBaseName (dir, name) {
    var files = fs.readdirSync(dir);
    for (let file of files) {
        if (extractFileName(file) === name) {
            return path.join(dir, file);
        }
    }

    return null;
}


function LindgeBankPresentationPlugin () {
    PluginBase.call(this, 'lindge-bank-presentation');

    this._documentContentType = 'lindge/document-loading-data';
    this._docUrlMatcher = /Translayer\/Bank\.Presentation\/Load\/([^\/]+)(?:\/([^\/]+))?/i;
    this._partsUrlMatcher = /Translayer\/Bank\.Presentation\/(?:LoadPart\/)?([^\/]+)(?:\/([^\/]+))?\/([^\/]+)/i;
    this._bankRoot = null;
}

util.inherits(LindgeBankPresentationPlugin, PluginBase);

/**
 * @param {String} root
 */
LindgeBankPresentationPlugin.prototype.setBankRoot = function(root) {
    if (typeof root == 'string' && root.length > 0) {
        this._bankRoot = path.resolve(root);
    } else {
        throw new Error("Invalid root");
    }

    return this;
};

LindgeBankPresentationPlugin.prototype.active = function(runtime) {
    if (this._bankRoot === null) {
        throw new Error("Bank root is not set");
    }

    var self = this;

    var notFoundResult = {
        code: HTTP_STATUS_CODE.notFound
    };

    function load (root, id, present) {
        var section = path.join(root, id);
        var docPath = path.join(section, present + '.lindge-doc');
        var userDataPath = path.join(section, 'userdata.json');

        if (!fileExists(docPath)) {
            return null;
        }

        var presentationData = {
            content: null,
            userData: null
        };

        presentationData.content = fs.readFileSync(docPath, miniserver.DEFAULT_TEXT_ENCODING);

        if (fileExists(userDataPath)) {
            presentationData.userData = fs.readFileSync(userDataPath, miniserver.DEFAULT_TEXT_ENCODING);
        }

        var bufferData = miniserver.encodeJSON(presentationData);

        return {
            code: HTTP_STATUS_CODE.success,
            headers: {
                'Content-Type': self._documentContentType,
                'Content-Length': bufferData.length
            },
            data: bufferData
        };
    }

    function loadPart (root, id, assetKey, present, rangeInfo) {
        function readByRange (fpath, range) {
            var fd = fs.openSync(fpath, 'r');
            var fileSize = fs.fstatSync(fd).size;
            var endPos = fileSize - 1;

            var start, end;
            if (isNaN(range[1])) {
                start = isNaN(range[0]) ? 0 : range[0];
                end = endPos;
            } else {
                if (isNaN(range[0])) {
                    // `-500` means taking last 500 bytes
                    start = endPos - range[1] + 1;
                    end = endPos;
                } else {
                    start = range[0];
                    end = range[1];
                }
            }
            if (end > endPos) {
                end = endPos;
            }

            var buffer = Buffer.alloc(end - start + 1, 0);
            var bytesRead = fs.readSync(fd, buffer, 0, buffer.length, start);
            if (bytesRead < buffer.length) {
                buffer = buffer.slice(0, bytesRead);
            }

            fs.closeSync(fd);

            return [buffer, `bytes ${start}-${start + bytesRead - 1}/${fileSize}`];
        }

        var assetDir;
        if (assetKey && present) {
            assetDir = path.join(root, id, assetKey);
        } else {
            assetDir = path.join(root, id);
        }

        if (dirExists(assetDir)) {
            var fpath = findByBaseName(assetDir, !!present ? present : assetKey);
            if (fpath === null) {
                return null;
            } else {
                var ext = path.extname(fpath).substr(1);
                var stream;
                if (rangeInfo) {
                    var streamInfo = readByRange(fpath, rangeInfo);
                    stream = streamInfo[0];
                    return {
                        code: HTTP_STATUS_CODE.partialContent,
                        headers: {
                            'Content-Type': MIME_TABLE[ext] || MIME_TABLE['binary'],
                            'Content-Length': stream.length,
                            'Content-Range': streamInfo[1]
                        },
                        data: stream
                    };
                } else {
                    stream = fs.readFileSync(fpath);
                    return {
                        code: HTTP_STATUS_CODE.success,
                        headers: {
                            'Content-Type': MIME_TABLE[ext] || MIME_TABLE['binary'],
                            'Content-Length': stream.length
                        },
                        data: stream
                    };
                }
            }
        } else {
            return null;
        }
    }

    runtime.registerEXHandler(HTTP_METHODS.GET, this._docUrlMatcher, function (urlInfo, headers, body, parts) {
        var docID = parts[0];
        var present = parts[1] || 'default';

        var result = load(self._bankRoot, docID, present);

        if (result === null) {
            return notFoundResult;
        } else {
            return result;
        }
    });

    runtime.registerEXHandler(HTTP_METHODS.GET, this._partsUrlMatcher, function (urlInfo, headers, body, parts) {
        var docID = parts[0];
        var assetID = parts[1] || '';
        var present = parts[2] || '';

        var rangeInfo;
        if (headers.range) {
            var matchers = /^bytes=([0-9]+)-([0-9]*)$/.exec(headers.range);
            if (matchers) {
                var start = parseInt(matchers[1]), end = parseInt(matchers[2]);
                rangeInfo = [start, end];
            } else {
                rangeInfo = null;
            }
        } else {
            rangeInfo = null;
        }


        var result = loadPart(self._bankRoot, docID, assetID, present, rangeInfo);

        if (result === null) {
            return notFoundResult;
        } else {
            return result;
        }
    });

    return this;
};


module.exports = LindgeBankPresentationPlugin;