const path = require('path');
const fs = require('fs');

var bankPlugin = require('../index.js');

const miniserver = require('mini-server-core');
const HTTP_METHODS = miniserver.HTTP_METHODS;
const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const MIME_TABLE = miniserver.MIME_TABLE;


describe("test bank presentation", function () {
    var root = path.join(__dirname, './resource');
    var plugin;
    beforeEach(function () {
        plugin = new bankPlugin();
        plugin.setBankRoot(root);
    });

    function createMockRuntime () {
        return {
            handlers: [],
            registerEXHandler: function (method, matcher, handler) {
                this.handlers.push({
                    method: method,
                    matcher: matcher,
                    handler: handler
                });
            }
        };
    }

    it("test doc loading", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handlerDoc = mockRuntime.handlers[0];

        expect(handlerDoc.method).toBe(HTTP_METHODS.GET);
        expect(handlerDoc.matcher.test('/Translayer/Bank.Presentation/Load/BHS_A7C8165CF0BB4338839888AFC3ECF5A9/')).toBe(true);
        expect(handlerDoc.matcher.test('/Translayer/Bank.Presentation/Load/BHS_A7C8165CF0BB4338839888AFC3ECF5A9/preview')).toBe(true);
        expect(handlerDoc.matcher.test('/Translayer/Bank.Presentation/Load')).toBe(false);

        var parts_1 = handlerDoc.matcher.exec('/Translayer/Bank.Presentation/Load/BHS_A7C8165CF0BB4338839888AFC3ECF5A9/').slice(1);
        var result_1 = handlerDoc.handler(null, {}, null, parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);

        var data_1 = JSON.parse(result_1.data.toString('utf8'));
        expect(data_1.content).toBe(fs.readFileSync(path.join(root, 'BHS_A7C8165CF0BB4338839888AFC3ECF5A9/default.lindge-doc'), 'utf8'));
        expect(data_1.userData).toBe(fs.readFileSync(path.join(root, 'BHS_A7C8165CF0BB4338839888AFC3ECF5A9/userdata.json'), 'utf8'));
    });

    it("test doc loading with present", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handlerDoc = mockRuntime.handlers[0];

        var parts_1 = handlerDoc.matcher.exec('/Translayer/Bank.Presentation/Load/BHS_A7C8165CF0BB4338839888AFC3ECF5A9/review').slice(1);
        var result_1 = handlerDoc.handler(null, {}, null, parts_1);

        var data_1 = JSON.parse(result_1.data.toString('utf8'));
        expect(data_1.content).toBe(fs.readFileSync(path.join(root, 'BHS_A7C8165CF0BB4338839888AFC3ECF5A9/review.lindge-doc'), 'utf8'));
        expect(data_1.userData).toBe(fs.readFileSync(path.join(root, 'BHS_A7C8165CF0BB4338839888AFC3ECF5A9/userdata.json'), 'utf8'));
    });

    it("test full parts load", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handlerPart = mockRuntime.handlers[1];

        expect(handlerPart.method).toBe(HTTP_METHODS.GET);
        expect(handlerPart.matcher.test('/Translayer/Bank.Presentation/LoadPart/BHS_A7C8165CF0BB4338839888AFC3ECF5A9/foo/bar')).toBe(true);
        expect(handlerPart.matcher.test('/Translayer/Bank.Presentation/BHS_A7C8165CF0BB4338839888AFC3ECF5A9/bar')).toBe(true);
        expect(handlerPart.matcher.test('/Translayer/Bank.Presentation/BHS_A7C8165CF0BB4338839888AFC3ECF5A9')).toBe(false);

        var parts_1 = handlerPart.matcher.exec('/Translayer/Bank.Presentation/LoadPart/BHS_A7C8165CF0BB4338839888AFC3ECF5A9/key1/review').slice(1);
        var result_1 = handlerPart.handler(null, {}, null, parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);
        expect(result_1.headers['Content-Type']).toBe(MIME_TABLE['mp4']);
    });

    it("test partial parts load", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var handlerPart = mockRuntime.handlers[1];

        var parts_1 = handlerPart.matcher.exec('/Translayer/Bank.Presentation/BHS_A7C8165CF0BB4338839888AFC3ECF5A7/default').slice(1);
        var result_1 = handlerPart.handler(null, {}, null, parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);
        expect(result_1.headers['Content-Type']).toBe(MIME_TABLE['png']);
    });
});