const path = require('path');
const fs = require('fs');
const util = require('util');
const constants = require('constants');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


const CACHE_TYPES = {
    BLOCK: "BLOCK",
    INCREMENTAL: "INCREMENTAL"
};

const SECTION_STATES = {
    BEGIN: "Begin",
    END: "End",
    SUSTAIN: "Sustain"
};

const BEHAVIOR_STATE = {
    DELETED: "DELETED",
    PROCESSING: "PROCESSING"
};

/**
 * data structure for behavior data getter
 */
function TimeRecordDataResult () {
    this.SystemPeriod = 0;
    this.SystemDuration = 0;
    this.EffectivePeriod = 0;
    this.BlockData = '';
    this.IncrementData = {};
}


function isObject (obj) {
    return typeof obj == 'object';
}

function isMap (m) {
    return m instanceof Map;
}

/**
 * test whether the given path is a file
 *
 * @param {String} fpath
 * @returns {Boolean}
 */
function fileExists (fpath) {
    try {
        return fs.statSync(fpath).isFile();
    } catch (e) {
        return false;
    }
}

const BlockBehaviorVisitor = {
    create: function (id) {
        var behaviorData = {
            "mode": CACHE_TYPES.BLOCK,
            "id": id,
            "records": [],
            "attrs": {},
            "state": BEHAVIOR_STATE.PROCESSING
        };

        return behaviorData;
    },
    load: function (behaviorData) {
        if (behaviorData.mode === CACHE_TYPES.BLOCK) {
            var records = behaviorData.records;
            for (let record of records) {
                if (record.state === SECTION_STATES.SUSTAIN) {
                    var result = new TimeRecordDataResult();
                    result.BlockData = record.additionData;
                    return result;
                }
            }

            return null;
        } else {
            throw new TypeError("Behavior data is not block type");
        }
    },
    add: function (behaviorData, data, time) {
        if (behaviorData.mode == CACHE_TYPES.BLOCK) {
            behaviorData.records.unshift({
                recordTime: time,
                state: SECTION_STATES.SUSTAIN,
                additionData: data
            });

            return behaviorData;
        } else {
            throw new TypeError("Behavior data is not block type");
        }
    }
};

const IncrementalBehaviorVisitor = {
    create: function (id) {
        var behaviorData = {
            "mode": CACHE_TYPES.INCREMENTAL,
            "id": id,
            "records": [],
            "attrs": {},
            "state": BEHAVIOR_STATE.PROCESSING
        };

        return behaviorData;
    },
    _computeTimespan: function (start, end) {
        if (start && end) {
            var startTime = (new Date(start)).getTime();
            var endTime = (new Date(end)).getTime();

            return Math.max(0, endTime - startTime);
        } else {
            return 0;
        }
    },
    _computeDuration: function (records) {
        if (records.length > 0) {
            var first = records[records.length - 1];
            var last = records[0];
            return this._computeTimespan(first.recordTime, last.recordTime);
        } else {
            return 0;
        }
    },
    load: function (behaviorData) {
        if (behaviorData.mode === CACHE_TYPES.INCREMENTAL) {
            var records = behaviorData.records;
            if (records.length > 0) {
                var output = {};
                var timeSpan = 0;
                var startTimeAnchor = null;
                var endTimeAnchor = null;

                for (var i = records.length - 1; i >= 0; i--) {
                    var record = records[i];
                    if (record.additionData !== null) {
                        Object.assign(output, record.additionData);
                    }

                    if (record.state === SECTION_STATES.BEGIN) {
                        if (startTimeAnchor) {
                            timeSpan += this._computeTimespan(startTimeAnchor, endTimeAnchor);
                        }

                        startTimeAnchor = record.recordTime;
                        endTimeAnchor = null;
                    } else if (record.state === SECTION_STATES.END || i === 0) {
                        timeSpan += this._computeTimespan(startTimeAnchor, record.recordTime);
                        startTimeAnchor = endTimeAnchor = null;
                    } else {
                        endTimeAnchor = record.recordTime;
                    }
                }

                var result = new TimeRecordDataResult();
                result.IncrementData = output;
                result.SystemPeriod = timeSpan;
                result.SystemDuration = this._computeDuration(records);

                return result;
            } else {
                return null;
            }
        } else {
            throw new TypeError("Behavior data is not incremental type");
        }
    },
    _isValidObject: function (obj) {
        return !Object.keys(obj).some((attr) => typeof obj[attr] != 'string');
    },
    _mapToBlockData: function (m) {
        var result = {};
        for (let [key, value] of m) {
            result[key] = value;
        }

        return result;
    },
    _isValidMap: function (map) {
        for (let [key, value] of map) {
            if (typeof key != 'string' || typeof value != 'string') {
                return false;
            }
        }

        return true;
    },
    add: function (behaviorData, data, time) {
        if (behaviorData.mode == CACHE_TYPES.INCREMENTAL) {
            if (data !== null) {
                if (isObject(data)) {
                    if (!this._isValidObject(data)) {
                        throw new Error("Invalid object");
                    }
                } else if (isMap(data)) {
                    if (!this._isValidMap(data)) {
                        throw new Error("Invalid map");
                    } else {
                        data = this._mapToBlockData(data);
                    }
                } else {
                    throw new TypeError("Invalid data");
                }
            }

            behaviorData.records.unshift({
                recordTime: time,
                state: SECTION_STATES.SUSTAIN,
                additionData: data
            });

            return behaviorData;
        } else {
            throw new TypeError("Behavior data is not incremental type");
        }
    }
};


/**
 * data storage connection
 *
 * @param {String} id  behavior id
 * @param {String} filepath  storage file path
 * @param {Object=} visitor
 *
 * @class
 */
function BehaviorDataConnection (id, filepath, visitor) {
    this._id = id;
    this._file = filepath;
    this._fd = -1;
    this._visitor = visitor || null;

    this._data = null;
    this._connected = false;
}

BehaviorDataConnection.prototype._setVisitorByType = function(type) {
    switch (type) {
        case CACHE_TYPES.BLOCK:
            this._visitor = BlockBehaviorVisitor;
            break;
        case CACHE_TYPES.INCREMENTAL:
            this._visitor = IncrementalBehaviorVisitor;
            break;
    }
};

BehaviorDataConnection.prototype._loadFile = function() {
    var flags = constants.O_RDWR | constants.O_EXCL | constants.O_SYNC;
    var fpath = this._file;
    var fileSize = fs.statSync(fpath).size;

    // read file
    var fd = fs.openSync(fpath, flags);
    var buffer = Buffer.alloc(fileSize, 0);
    fs.readSync(fd, buffer, 0, fileSize, 0);

    // deserialize and save file data
    var strData = buffer.toString(miniserver.DEFAULT_TEXT_ENCODING);
    this._data = JSON.parse(strData);
    this._fd = fd;

    if (this._visitor === null) {
        this._setVisitorByType(this._data.mode);
    }
};

BehaviorDataConnection.prototype._saveFile = function() {
    // truncate file
    fs.ftruncateSync(this._fd);
    // generate new content
    var strData = JSON.stringify(this._data);
    // write to file
    fs.writeSync(this._fd, strData, 0, miniserver.DEFAULT_TEXT_ENCODING);
};

BehaviorDataConnection.prototype._getTime = function() {
    return (new Date()).toJSON();
};

/**
 * build connection with underlay storage
 */
BehaviorDataConnection.prototype.connect = function() {
    if (!this._connected) {
        if (!fileExists(this._file)) {
            var initData = this._visitor.create(this._id);
            fs.writeFileSync(this._file, JSON.stringify(initData), { encoding: miniserver.DEFAULT_TEXT_ENCODING });
        }

        this._loadFile();
        this._connected = true;
    }

    return this;
};

BehaviorDataConnection.prototype.dispose = function() {
    if (this._connected) {
        fs.closeSync(this._fd);
        this._fd = -1;
        this._data = null;
        this._connected = false;
    }
};

/**
 * @returns {Any}
 */
BehaviorDataConnection.prototype.loadRecord = function() {
    return this._visitor.load(this._data);
};

/**
 * @param {Any} record
 */
BehaviorDataConnection.prototype.saveRecord = function(record) {
    this._visitor.add(this._data, record, this._getTime());

    // update file
    this._saveFile();
};

BehaviorDataConnection.prototype.beginSection = function() {
    if (this._data) {
        this._data.records.unshift({
            recordTime: this._getTime(),
            state: SECTION_STATES.BEGIN,
            additionData: null
        });

        this._saveFile();
    }
};

BehaviorDataConnection.prototype.endSection = function() {
    if (this._data) {
        this._data.records.unshift({
            recordTime: this._getTime(),
            state: SECTION_STATES.END,
            additionData: null
        });

        this._saveFile();
    }
};

BehaviorDataConnection.prototype.getAttr = function(attrList) {
    var attrs = this._data.attrs;
    var result = {};

    for (let name of attrList) {
        if (attrs.hasOwnProperty(name)) {
            result[name] = attrs[name];
        } else {
            result[name] = null;
        }
    }

    return result;
};

/**
 * @param {Object} attrMapping
 */
BehaviorDataConnection.prototype.setAttr = function(attrMapping) {
    if (this._data) {
        for (let name of Object.keys(attrMapping)) {
            var value = attrMapping[name];
            if (typeof value == 'string' || value === null) {
                this._data.attrs[name] = value;
            } else {
                throw new Error("Invalid value for attribute: " + name);
            }
        }

        this._saveFile();
    }
};

/**
 * @param {String} state
 */
BehaviorDataConnection.prototype.setState = function(state) {
    this._data.state = state;
};

/**
 * @return {Boolean}
 */
BehaviorDataConnection.prototype.isProcessing = function() {
    return this._data.state == BEHAVIOR_STATE.PROCESSING;
};


/**
 * plugin class
 */
function LindgeBehaviorPlugin () {
    PluginBase.call(this, 'lindge-behavior');

    this._storageRoot = null;
    this._connectionPool = {};
}

util.inherits(LindgeBehaviorPlugin, PluginBase);

LindgeBehaviorPlugin.prototype.CACHE_TYPES = CACHE_TYPES;

LindgeBehaviorPlugin.prototype.BEHAVIOR_STATE = BEHAVIOR_STATE;

/**
 * @param {String} id
 * @returns {Boolean}
 */
LindgeBehaviorPlugin.prototype.behaviorExists = function(id) {
    var filepath = this._getFilePathByID(id);
    return fileExists(filepath);
};

/**
 * @param {String} behaviorID
 * @param {Object=} visitor
 *
 * @returns {BehaviorDataConnection}
 */
LindgeBehaviorPlugin.prototype._getConnection = function(behaviorID, visitor) {
    var pool = this._connectionPool;
    var conn = pool[behaviorID];
    if (!conn) {
        var filePath = this._getFilePathByID(behaviorID);
        if (fileExists(filePath)) {
            // create and save pool
            if (arguments.length > 1) {
                conn = new BehaviorDataConnection(behaviorID, filePath, visitor);
            } else {
                conn = new BehaviorDataConnection(behaviorID, filePath);
            }
            conn.connect();
            pool[behaviorID] = conn;
            return conn;
        } else {
            return null;
        }
    } else {
        return conn;
    }
};

/**
 * @param {String} root
 */
LindgeBehaviorPlugin.prototype.setStorageRoot = function(root) {
    if (typeof root == 'string' && root.length > 0) {
        this._storageRoot = path.resolve(root);
    } else {
        throw new Error("Invalid storage root");
    }

    return this;
};

/**
 * @param {String} id behavior id
 * @returns {String} possible behavior storage file path
 */
LindgeBehaviorPlugin.prototype._getFilePathByID = function(id) {
    return path.join(this._storageRoot, id + '.json');
};

/**
 * @param {String} type
 * @returns {Object}
 */
LindgeBehaviorPlugin.prototype._getVisitorByType = function(type) {
    switch (type) {
        case CACHE_TYPES.BLOCK:
            return BlockBehaviorVisitor;
        case CACHE_TYPES.INCREMENTAL:
            return IncrementalBehaviorVisitor;
        default:
            throw new Error(`Invalid storage type: ${type}`);
    }
};

/**
 * create initial storage for given behavior
 *
 * @param {String} id  behavior id
 * @param {String} type storage type
 */
LindgeBehaviorPlugin.prototype.createStorage = function(id, type) {
    if (typeof id == 'string' && id.length > 0) {
        var visitor = this._getVisitorByType(type);
        var initData = visitor.create(id);
        var fpath = this._getFilePathByID(id);
        fs.writeFileSync(fpath, JSON.stringify(initData), { encoding: miniserver.DEFAULT_TEXT_ENCODING, flag: 'w' });

        return this;
    } else {
        throw new Error("Invalid id");
    }
};

/**
 * @param {String} id
 * @param {String} type
 * @param {any} data
 */
LindgeBehaviorPlugin.prototype.pushRecord = function(id, type, data) {
    if (typeof id == 'string' && id.length > 0) {
        var visitor = this._getVisitorByType(type);
        var conn = this._getConnection(id, visitor);
        if (conn === null) {
            throw new Error(`Build connection with behavior ${id} failed`);
        } else {
            conn.saveRecord(data);
        }

        return this;
    } else {
        throw new Error("Invalid id");
    }
};

/**
 * remove behavior
 *
 * @param {String} id
 */
LindgeBehaviorPlugin.prototype.removeBehavior = function(id) {
    var pool = this._connectionPool;
    var conn = pool[id];

    if (conn) {
        conn.dispose();
        delete pool[id];
    }

    var fpath = this._getFilePathByID(id);
    if (fileExists(fpath)) {
        fs.unlinkSync(fpath);
    }

    return this;
};

/**
 * @param {String} id
 * @param {Object} attrs
 */
LindgeBehaviorPlugin.prototype.setBehaviorAttrs = function(id, attrs) {
    if (!id) {
        throw new Error("id is null");
    }

    if (typeof attrs == 'object') {
        if (Object.keys(attrs).length > 0) {
            var conn = this._getConnection(id);
            conn.setAttr(attrs);
        }

        return this;
    } else {
        throw new TypeError("attrs must be Object");
    }
};

/**
 * @param {String} id
 * @param {String} state
 */
LindgeBehaviorPlugin.prototype.markBehaviorState = function(id, state) {
    if (!id) {
        throw new Error("id is null");
    }

    if (!state) {
        throw new Error("state is null");
    }

    var conn = this._getConnection(id);
    conn.setState(state);

    return this;
};

LindgeBehaviorPlugin.prototype.active = function(runtime) {
    if (this._storageRoot === null) {
        throw new Error("Storage path is not null");
    }

    var self = this;
    var pool = this._connectionPool;

    // destory all connections when exiting
    process.on('exit', function () {
        Object.keys(pool).forEach(function (id) {
            pool[id].dispose();
        });
    });

    var normalSuccessResult = {
        code: HTTP_STATUS_CODE.success
    };

    var notfoundResult = {
        code: HTTP_STATUS_CODE.notFound,
        headers: {
            'Content-Type': 'text/plain'
        },
        data: Buffer.from("Entify not found", miniserver.DEFAULT_TEXT_ENCODING)
    };

    var invalidOperationResult = {
        code: HTTP_STATUS_CODE.gone,
        headers: {
            'Content-Type': 'text/plain'
        },
        data: Buffer.from("Behavior is terminated", miniserver.DEFAULT_TEXT_ENCODING)
    };

    function generateDataResponse (data) {
        var bufferData = miniserver.encodeJSON(data);
        return {
            code: HTTP_STATUS_CODE.success,
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': bufferData.length
            },
            data: bufferData
        };
    }

    // section controllers
    runtime.registerEXHandler(HTTP_METHODS.PUT,
        /Translayer\/Behavior\.Activity\/api\/BehaviorTimeRecordSection\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID);

            if (conn === null) {
                return notfoundResult;
            } else {
                if (conn.isProcessing()) {
                    conn.beginSection();
                    return normalSuccessResult;
                } else {
                    return invalidOperationResult;
                }
            }
        });

    runtime.registerEXHandler(HTTP_METHODS.POST,
        /Translayer\/Behavior\.Activity\/api\/BehaviorTimeRecordSection\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID);

            if (conn === null) {
                return notfoundResult;
            } else {
                if (conn.isProcessing()) {
                    conn.endSection();
                    return normalSuccessResult;
                } else {
                    return invalidOperationResult;
                }
            }
        });

    // block data controller
    runtime.registerEXHandler(HTTP_METHODS.GET,
        /Translayer\/Behavior\.Activity\/api\/BehaviorTimeRecordBlockData\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID, self._getVisitorByType(CACHE_TYPES.BLOCK));

            if (conn === null) {
                return notfoundResult;
            } else {
                var record = conn.loadRecord();
                return generateDataResponse(record);
            }
        });

    runtime.registerEXHandler(HTTP_METHODS.PUT,
        /Translayer\/Behavior\.Activity\/api\/BehaviorTimeRecordBlockData\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID, self._getVisitorByType(CACHE_TYPES.BLOCK));

            if (conn === null) {
                return notfoundResult;
            } else if (!conn.isProcessing()) {
                return invalidOperationResult;
            } else {
                conn.saveRecord(body);
                return normalSuccessResult;
            }
        });

    // incremental data controller
    runtime.registerEXHandler(HTTP_METHODS.GET,
        /Translayer\/Behavior\.Activity\/api\/BehaviorTimeRecordIncrementData\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID, self._getVisitorByType(CACHE_TYPES.INCREMENTAL));

            if (conn === null) {
                return notfoundResult;
            } else {
                var record = conn.loadRecord();
                return generateDataResponse(record);
            }
        });

    runtime.registerEXHandler(HTTP_METHODS.PUT,
        /Translayer\/Behavior\.Activity\/api\/BehaviorTimeRecordIncrementData\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID, self._getVisitorByType(CACHE_TYPES.INCREMENTAL));

            if (conn === null) {
                return notfoundResult;
            } else if (!conn.isProcessing()) {
                return invalidOperationResult;
            } else {
                conn.saveRecord(body);
                return normalSuccessResult;
            }
        });

    // attribute controller
    runtime.registerEXHandler(HTTP_METHODS.PUT,
        /Translayer\/Behavior\.Activity\/api\/BehaviorAttribute\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID);

            if (conn === null) {
                return notfoundResult;
            } else {
                conn.setAttr(body);
                return normalSuccessResult;
            }
        });

    runtime.registerEXHandler(HTTP_METHODS.POST,
        /Translayer\/Behavior\.Activity\/api\/BehaviorAttribute\/(.+)/,
        function (urlInfo, headers, body, parts) {
            var behaviorID = parts[0];
            var conn = self._getConnection(behaviorID);

            if (conn === null) {
                return notfoundResult;
            } else {
                var attrs = conn.getAttr(body);
                return generateDataResponse(attrs);
            }
        });

    return this;
};


module.exports = LindgeBehaviorPlugin;