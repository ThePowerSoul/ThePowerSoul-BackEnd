#### lindge-behavior

模拟平台行为服务，支持增量/非增量模式行为数据的查询、写入。

__属性__

`CACHE_TYPES`

缓存类型枚举

* BLOCK - 非增量型缓存
* INCREMENTAL - 增量型缓存

`BEHAVIOR_STATE`

* PROCESSING - 过程中，普通状态
* DELETED - 已删除


__方法__

`setStorageRoot(root: String) -> this`

指定配置文件存储根目录

`createStorage(id: String, type: CACHE_TYPES) -> this`

根据输入的行为标识在存储位置想创建相应的存储文件，并写入初始数据。

```javascript
var behaviorService = plugins
    .load('lindge-behavior')
    .setStorageRoot(process.cwd() + '/behavior')
    .active(runtime);

// 创建一个非增量型行为缓存
behaviorService.createStorage('xxx', behaviorService.CACHE_TYPES.BLOCK);
```

`pushRecord(id: String, type: CACHE_TYPES, data: any) -> this`

根据行为标识向指定行为存储里添加数据，如果行为不存在或数据不符合规范则添加失败。

```javascript
var behaviorService = plugins
    .load('lindge-behavior')
    .setStorageRoot(process.cwd() + '/behavior')
    .active(runtime);

behaviorService.createStorage('xxx_block', behaviorService.CACHE_TYPES.BLOCK);
// block 类型缓存可以存储任何数据结构
behaviorService.pushRecord('xxx_block', behaviorService.CACHE_TYPES.BLOCK, 'this is a record');

behaviorService.createStorage('xxx_incre', behaviorService.CACHE_TYPES.INCREMENTAL);
// incremental 类型缓存只能存储 Dict<String, String> 类型的数据结构
behaviorService.pushRecord('xxx_incre', behaviorService.CACHE_TYPES.INCREMENTAL, {
    'foo': JSON.stringify('this is a record')
});

behaviorService.pushRecord('xxx_incre', behaviorService.CACHE_TYPES.INCREMENTAL, {
    'foo': [1, 2, 3],
    'bar': 'this is a record'
});     // -> TypeError
```

`behaviorExists(id: String) -> Boolean`

查询指定行为是否存在

`removeBehavior(id: String) -> this`

根据标识移除指定行为，该方法不但会移除行为配置文件(如果存在)，还会关闭底层文件链接。

在运行时 __只能__ 使用该方法删除行为，如果希望在server运行过程中手动清理或修改行为配置文件，必须先关闭sever，修改后重新启动。

__配置__

行为存储的最基本单元为以行为标识为文件名的json文件，初始配置项如下：

```javascript
{
    // 存储类型, "BLOCK" | "INCREMENTAL"
    "mode": "BLOCK",
    // 行为标识
    "id": "277e97cdf9fa4438bd7e41b58bd928d9",
    // 记录列表
    "records": [{
        // 记录时间
        "recordTime": "2017-04-18 06:37:34.307",
        // 行为状态, "Sustain" | "Begin" | "End"
        "state": "Sustain",
        // 行为数据，类型为字符串
        "additionData": "aaa"
    }],
    // 行为属性映射表
    "attrs": {},
    // 行为状态, "PROCESSING" | "DELETED"
    "state": "PROCESSING"
}
```

`setBehaviorAttrs(id: String, attrs: Object) -> this`

写入行为属性。

`markBehaviorState(id: String, state: BEHAVIOR_STATE) -> this`

修改行为状态，如果将状态设为`DELETED`，之后所有通过请求发起的对行为的修改操作(修改属性除外)都会返回410