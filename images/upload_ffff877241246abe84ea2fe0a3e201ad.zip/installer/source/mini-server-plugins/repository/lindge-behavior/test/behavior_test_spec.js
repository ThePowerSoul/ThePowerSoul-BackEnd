const path = require('path');
const fs = require('fs');

var behaviorPlugin = require('../index.js');

const miniserver = require('mini-server-core');
const HTTP_METHODS = miniserver.HTTP_METHODS;
const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const MIME_TABLE = miniserver.MIME_TABLE;


describe("test behavior", function () {
    var root = path.join(__dirname, './resource');
    var plugin;
    var tempFiles = [];

    beforeEach(function () {
        plugin = new behaviorPlugin();
        plugin.setStorageRoot(root);
    });

    function createTempFile (fname) {
        var fpath = path.join(root, fname);
        tempFiles.push(fpath);
        return fpath;
    }

    function write2TempFile (fname, content) {
        var fpath = path.join(root, fname);
        fs.writeFileSync(fpath, content, { encoding: miniserver.DEFAULT_TEXT_ENCODING, flag: 'w' });
    }

    function readFromeTempFile(fname) {
        var fpath = path.join(root, fname);
        return fs.readFileSync(fpath, miniserver.DEFAULT_TEXT_ENCODING);
    }

    function clearTempFiles () {
        for (let fpath of tempFiles) {
            try {
                fs.unlinkSync(fpath);
            } catch (e) {}
        }

        tempFiles.length = 0;
    }

    afterEach(clearTempFiles);
    process.on('exit', clearTempFiles);

    function createMockRuntime () {
        return {
            handlers: [],
            registerEXHandler: function (method, matcher, handler) {
                this.handlers.push({
                    method: method,
                    matcher: matcher,
                    handler: handler
                });
            }
        };
    }

    /**
     * @param {Buffer} stream
     */
    function extractBlockData (stream) {
        if (Buffer.isBuffer(stream)) {
            var obj = JSON.parse(stream.toString(miniserver.DEFAULT_TEXT_ENCODING));
            return {
                time: obj.SystemPeriod,
                data: obj.BlockData
            };
        } else {
            return null;
        }
    }

    /**
     * @param {Buffer} stream
     */
    function extractIncrementalData (stream) {
        if (Buffer.isBuffer(stream)) {
            var obj = JSON.parse(stream.toString(miniserver.DEFAULT_TEXT_ENCODING));
            return {
                time: obj.SystemPeriod,
                data: obj.IncrementData
            };
        } else {
            return null;
        }
    }

    it("test behavior section", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var beginHandler = mockRuntime.handlers[0];
        var endHandler = mockRuntime.handlers[1];

        expect(beginHandler.method).toBe(HTTP_METHODS.PUT);
        expect(endHandler.method).toBe(HTTP_METHODS.POST);

        var testID = 'd3e6a65e54de45938b3ddbcec29e12b6';
        var filename = `${testID}.json`;
        createTempFile(filename);
        write2TempFile(filename, JSON.stringify({
            "mode": "BLOCK",
            "id": testID,
            "records": [],
            "state": "PROCESSING"
        }));

        var fileData;

        var parts_1 = beginHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorTimeRecordSection/${testID}`).slice(1);
        var result_1 = beginHandler.handler({}, {}, null, parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);

        fileData = JSON.parse(readFromeTempFile(filename));
        expect(fileData.records).toEqual([jasmine.objectContaining({
            "state": "Begin",
            "additionData": null
        })]);

        var parts_2 = endHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorTimeRecordSection/${testID}`).slice(1);
        var result_2 = endHandler.handler({}, {}, null, parts_2);
        expect(result_2.code).toBe(HTTP_STATUS_CODE.success);

        fileData = JSON.parse(readFromeTempFile(filename));
        expect(fileData.records).toEqual([
            jasmine.objectContaining({
                "state": "End",
                "additionData": null
            }),
            jasmine.objectContaining({
                "state": "Begin",
                "additionData": null
            })
        ]);

        var parts_3 = beginHandler.matcher.exec('/Translayer/Behavior.Activity/api/BehaviorTimeRecordSection/foo').slice(1);
        var result_3 = beginHandler.handler({}, {}, null, parts_3);
        expect(result_3.code).toBe(HTTP_STATUS_CODE.notFound);
    });

    it("test behavior block data", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var getHandler = mockRuntime.handlers[2];
        var saveHandler = mockRuntime.handlers[3];

        expect(getHandler.method).toBe(HTTP_METHODS.GET);
        expect(saveHandler.method).toBe(HTTP_METHODS.PUT);

        var testID = 'c5cb40c93d8b43b385622ba2828ff44a';
        var filename = `${testID}.json`;
        var initData = {
            "mode": "BLOCK",
            "id": testID,
            "records": [{
                "recordTime": "2017-04-18 06:37:34.307",
                "state": "Sustain",
                "additionData": "aaa"
            }],
            "state": "PROCESSING"
        };
        createTempFile(filename);
        write2TempFile(filename, JSON.stringify(initData));

        var fileData;

        var parts_1 = getHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorTimeRecordBlockData/${testID}`).slice(1);
        var result_1 = getHandler.handler({}, {}, null, parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);

        fileData = extractBlockData(result_1.data);
        expect(fileData.data).toEqual(initData.records[0].additionData);

        var parts_2 = saveHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorTimeRecordBlockData/${testID}`).slice(1);
        var result_2 = saveHandler.handler({}, {}, 'bbb', parts_2);
        expect(result_2.code).toBe(HTTP_STATUS_CODE.success);

        fileData = JSON.parse(readFromeTempFile(filename));
        expect(fileData.records).toEqual([
            jasmine.objectContaining({
                "state": "Sustain",
                "additionData": 'bbb'
            }),
            jasmine.objectContaining({
                "state": "Sustain",
                "additionData": 'aaa'
            })
        ]);

        var result_3 = getHandler.handler({}, {}, null, parts_1);
        fileData = extractBlockData(result_3.data);
        expect(fileData.data).toEqual('bbb');
    });

    it("test behavior incremental data", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var getHandler = mockRuntime.handlers[4];
        var saveHandler = mockRuntime.handlers[5];

        expect(getHandler.method).toBe(HTTP_METHODS.GET);
        expect(saveHandler.method).toBe(HTTP_METHODS.PUT);

        var testID = '4bb41b080fd04f0c9f3974a07e91c100';
        var filename = `${testID}.json`;
        var initData = {
            "mode": "INCREMENTAL",
            "id": testID,
            "records": [ {
                "recordTime": "2017-04-18 07:37:34.307",
                "state": "End",
                "additionData": null
            }, {
                "recordTime": "2017-04-18 06:37:34.307",
                "state": "Sustain",
                "additionData": {
                    "key1": "foo"
                }
            }, {
                "recordTime": "2017-04-18 05:37:34.307",
                "state": "Begin",
                "additionData": null
            }],
            "state": "PROCESSING"
        };
        createTempFile(filename);
        write2TempFile(filename, JSON.stringify(initData));

        var fileData;

        var parts_1 = getHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorTimeRecordIncrementData/${testID}`).slice(1);
        var result_1 = getHandler.handler({}, {}, null, parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);

        fileData = extractIncrementalData(result_1.data);
        expect(fileData.data).toEqual({ "key1": "foo" });

        var parts_2 = saveHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorTimeRecordIncrementData/${testID}`).slice(1);
        var result_2 = saveHandler.handler({}, {}, { "key2": "bar", "key3": "sha" }, parts_2);
        expect(result_2.code).toBe(HTTP_STATUS_CODE.success);

        fileData = JSON.parse(readFromeTempFile(filename));
        expect(fileData.records).toEqual([
            jasmine.objectContaining({
                "state": "Sustain",
                "additionData": {
                    "key2": "bar",
                    "key3": "sha"
                }
            }),
            jasmine.objectContaining({
                "state": "End",
                "additionData": null
            }),
            jasmine.objectContaining({
                "state": "Sustain",
                "additionData": {
                    "key1": "foo"
                }
            }),
            jasmine.objectContaining({
                "state": "Begin",
                "additionData": null
            })
        ]);

        var result_3 = getHandler.handler({}, {}, null, parts_1);
        fileData = extractIncrementalData(result_3.data);
        expect(fileData.data).toEqual({
            "key1": "foo",
            "key2": "bar",
            "key3": "sha"
        });
    });

    it("test behavior attribute", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var setHandler = mockRuntime.handlers[6];
        var getHandler = mockRuntime.handlers[7];

        expect(setHandler.method).toBe(HTTP_METHODS.PUT);
        expect(getHandler.method).toBe(HTTP_METHODS.POST);

        var testID = '28e01df1dd7c4be0b093784c5ed172c7';
        var filename = `${testID}.json`;
        var initData = {
            "mode": "BLOCK",
            "id": testID,
            "records": [{
                "recordTime": "2017-04-18 05:37:34.307",
                "state": "Sustain",
                "additionData": 'aaa'
            }],
            "attrs": {
                "attr1": "foo"
            },
            "state": "PROCESSING"
        };
        createTempFile(filename);
        write2TempFile(filename, JSON.stringify(initData));

        var fileData;

        var parts_1 = getHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorAttribute/${testID}`).slice(1);
        var result_1 = getHandler.handler({}, {}, ['attr1', 'attr2'], parts_1);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.success);

        fileData = JSON.parse(result_1.data.toString(miniserver.DEFAULT_TEXT_ENCODING));
        expect(fileData).toEqual({
            "attr1": "foo",
            "attr2": null
        });

        var parts_2 = setHandler.matcher.exec(`/Translayer/Behavior.Activity/api/BehaviorAttribute/${testID}`).slice(1);
        var result_2 = setHandler.handler({}, {}, { "attr2": "bar", "attr3": "sha" }, parts_2);
        expect(result_2.code).toBe(HTTP_STATUS_CODE.success);

        fileData = JSON.parse(readFromeTempFile(filename));
        expect(fileData.attrs).toEqual({
            "attr1": "foo",
            "attr2": "bar",
            "attr3": "sha"
        });

        var result_3 = getHandler.handler({}, {}, ['attr1', 'attr2', 'attr3'], parts_1);
        fileData = JSON.parse(result_3.data.toString(miniserver.DEFAULT_TEXT_ENCODING));
        expect(fileData).toEqual({
            "attr1": "foo",
            "attr2": "bar",
            "attr3": "sha"
        });
    });

    it("test behavior state", function () {
        var mockRuntime = createMockRuntime();
        plugin.active(mockRuntime);

        var sectionHandler = mockRuntime.handlers[1];

        var testID = 'adf1ab973caf42a486fde86e2bff2316';
        var filename = `${testID}.json`;
        var initData = {
            "mode": "BLOCK",
            "state": "PROCESSING",
            "id": testID,
            "records": [{
                "recordTime": "2017-04-18 05:37:34.307",
                "state": "Sustain",
                "additionData": 'aaa'
            }],
            "attrs": {
                "attr1": "foo"
            }
        };

        createTempFile(filename);
        write2TempFile(filename, JSON.stringify(initData));

        plugin.markBehaviorState(testID, plugin.BEHAVIOR_STATE.DELETED);

        var result_1 = sectionHandler.handler({}, {}, null, [testID]);
        expect(result_1.code).toBe(HTTP_STATUS_CODE.gone);
    });
});