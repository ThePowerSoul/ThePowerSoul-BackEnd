const util = require('util');
const fs = require('fs');
const path = require('path');
const url = require('url');
const constants = require('constants');

const uuid = require('uuid');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;

const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;
const MIME_TABLE = miniserver.MIME_TABLE;


/**
 * @param {String} fpath  file path
 * @returns {Boolean}
 */
function isFile (fpath) {
    try {
        return fs.statSync(fpath).isFile();
    } catch (err) {
        return false;
    }
}

/**
 * @param {String} dpath  directory path
 * @returns {Boolean}
 */
function isDir (dpath) {
    try {
        return fs.statSync(dpath).isDirectory();
    } catch (err) {
        return false;
    }
}

/**
 * @param {Boolean=} noSep
 * @param {String}
 */
function getUUID (noSep) {
    var uid = uuid.v4();
    if (noSep) {
        uid = uid.replace(/-/g, '');
    }

    return uid;
}


/**
 * @param {Number} fd  file descriptor
 *
 * @constructor
 */
function FileOperator (fd) {
    this._fd = fd;
    this._offset = 0;
}

/**
 * @returns {Number}
 */
FileOperator.prototype.size = function() {
    return fs.fstatSync(this._fd).size;
};

FileOperator.prototype.seekToEnd = function() {
    if (this._fd !== null) {
        var size = fs.fstatSync(this._fd).size;
        this._offset = size;

        return this;
    } else {
        throw new Error("This file is closed");
    }
};

FileOperator.prototype.seekToStart = function() {
    if (this._fd !== null) {
        this._offset = 0;

        return this;
    } else {
        throw new Error("This file is closed");
    }
};

/**
 * @param {Number} pos
 */
FileOperator.prototype.seek = function(pos) {
    if (this._fd !== null) {
        pos = parseInt(pos);
        if (isNaN(pos)) {
            throw new TypeError("Invalid position");
        }

        var size = fs.fstatSync(this._fd).size;

        if (pos < 0) {
            this.seekToStart();
        } else if (pos >= size) {
            this.seekToEnd();
        } else {
            this._offset = pos;
        }

        return this;
    } else {
        throw new Error("This file is closed");
    }
};

/**
 * @param {Buffer} buffer
 */
FileOperator.prototype.write = function(buffer) {
    var bytesWritten = fs.writeSync(this._fd, buffer, 0, buffer.length, this._offset);
    this._offset += bytesWritten;
    return this;
};

/**
 * @param {Number=} size
 * @param {Buffer}
 */
FileOperator.prototype.read = function(size) {
    if (arguments.length < 1) {
        size = fs.fstatSync(this._fd).size;
    }

    var buffer = Buffer.alloc(size);
    var bytesRead = fs.readSync(this._fd, buffer, 0, buffer.length, this._offset);

    if (bytesRead < buffer.length) {
        buffer = buffer.slice(0, bytesRead);
    }

    this._offset += bytesRead;

    return buffer;
};

FileOperator.prototype.close = function() {
    if (this._fd) {
        fs.closeSync(this._fd);
        this._fd = null;
        this._offset = 0;
    }
};

FileOperator.prototype.dispose = FileOperator.prototype.close;


/**
 * plugin class
 */
function LindgeCasualStreamPlugin () {
    PluginBase.call(this, 'lindge-casualstream');

    this._schema = 'file';
    this._serviceName = 'Bank2.CasualStream';

    this._storageRoot = null;

    this._connections = {};
}

util.inherits(LindgeCasualStreamPlugin, PluginBase);

/**
 * @param {String} root
 */
LindgeCasualStreamPlugin.prototype.setStorageRoot = function(root) {
    if (typeof root == 'string' && root.length > 0) {
        this._storageRoot = path.resolve(root);
    } else {
        throw new Error("Invalid storage root");
    }

    return this;
};

/**
 * @param {String?} session
 * @param {String} fileID
 *
 * @returns {String}
 */
LindgeCasualStreamPlugin.prototype._generateStorageID = function(session, fileID) {
    if (typeof fileID != 'string' || fileID.length === 0) {
        throw new Error("Invalid fileID");
    }

    var parts = [`${this._schema}://${this._serviceName}`];

    if (session) {
        parts.push(session);
    }

    parts.push(fileID);

    return parts.join('/');
};

/**
 * @param {String} id
 * @returns {[String, String]}
 */
LindgeCasualStreamPlugin.prototype._parseStorageID = function(id) {
    if (typeof id == 'string') {
        var info = url.parse(id);
        var pathname = info.pathname;
        if (info.protocol === null || info.host === null || pathname === null) {
            return null;
        } else {
            if (pathname.charAt(0) == '/') {
                pathname = pathname.substr(1);
            }

            var parts = pathname.split('/');
            if (parts.length > 1) {
                return [parts[0], parts[1]];
            } else {
                return [null, parts[0]];
            }
        }
    } else {
        throw new TypeError("ID must be string");
    }
};

/**
 * @param {String} session
 * @param {String} fileID
 * @param {Boolean} createNew
 *
 * @returns {FileOperator}
 */
LindgeCasualStreamPlugin.prototype._loadConnectionByID = function(session, fileID, createNew) {
    var fpath;
    if (session) {
        fpath = path.join(this._storageRoot, session, fileID);
    } else {
        fpath = path.join(this._storageRoot, fileID);
    }

    var flags = constants.O_RDWR | constants.O_CREAT | constants.O_SYNC;

    if (isFile(fpath) || createNew) {
        var fd = fs.openSync(fpath, flags);
        return new FileOperator(fd);
    } else {
        return null;
    }
};

LindgeCasualStreamPlugin.prototype._ensureStorage = function() {
    if (!isDir(this._storageRoot)) {
        fs.mkdirSync(this._storageRoot);
    }
};

LindgeCasualStreamPlugin.prototype.active = function(runtime) {
    if (this._storageRoot === null) {
        throw new Error("Storage root is not set");
    }

    this._ensureStorage();

    var self = this;
    var pool = this._connections;

    // clean up files
    process.on('exit', function () {
        Object.keys(pool).forEach(function (id) {
            pool[id].close();
        });
    });

    // begin uploading
    runtime.registerEXHandler(HTTP_METHODS.PUT, /Translayer\/Bank\.CasualStream\/stream/i,
    function (urlInfo, headers) {
        var session, fileID;

        var userHandle = urlInfo.queryParams['handle'];
        if (userHandle) {
            var handleInfo = self._parseStorageID(userHandle);
            if (handleInfo) {
                session = handleInfo[0];
                fileID = handleInfo[1];
            } else {
                return {
                    code: HTTP_METHODS.badRequest
                };
            }
        } else {
            session = null;
            fileID = getUUID(true);
        }

        var storageID = self._generateStorageID(session, fileID);

        var file = pool[storageID];
        if (!file) {
            self._ensureStorage();
            file = self._loadConnectionByID(session, fileID, true);
            pool[storageID] = file;
        }

        file.seekToStart();

        var result = {
            "Handle": storageID
        };

        var bufferData = miniserver.encodeJSON(result);

        return {
            code: HTTP_STATUS_CODE.success,
            headers: {
                'Content-Length': result.length,
                'Content-Type': 'application/json'
            },
            data: bufferData
        };
    });

    // uploading
    runtime.registerEXHandler(HTTP_METHODS.POST, /Translayer\/Bank\.CasualStream\/upload/i,
    function (urlInfo, headers, chunk) {
        if (Buffer.isBuffer(chunk)) {
            if (chunk.length > 0) {
                var storageID = headers['Handle'] || headers['handle'];

                var file = pool[storageID];
                if (!file) {
                    var [session, fileID] = self._parseStorageID(storageID);
                    file = self._loadConnectionByID(session, fileID, false);
                    if (file === null) {
                        throw new Error(`Storage for ${storageID} is not created`);
                    } else {
                        pool[storageID] = file;
                    }
                }

                file.seekToEnd();
                file.write(chunk);
            }
        } else {
            throw new TypeError("Uploading data must be bytes");
        }

        return {
            code: HTTP_STATUS_CODE.success
        };
    });

    // end uplaoding
    runtime.registerEXHandler(HTTP_METHODS.DELETE, /Translayer\/Bank\.CasualStream\/stream/i,
    function (urlInfo) {
        var handle = urlInfo.queryParams['handle'];
        if (handle) {
            var file = pool[handle];
            if (file) {
                file.close();
                delete pool[handle];
            }

            return {
                code: HTTP_STATUS_CODE.success
            };
        } else {
            return {
                code: HTTP_STATUS_CODE.badRequest
            };
        }
    });

    function tryGetRange (headers, endPos) {
        if (headers.range) {
            var matchers = /^bytes=([0-9]+)-([0-9]*)$/.exec(headers.range);
            if (matchers) {
                var range = [parseInt(matchers[1]), parseInt(matchers[2])];

                var start, end;
                if (isNaN(range[1])) {
                    start = isNaN(range[0]) ? 0 : range[0];
                    end = endPos;
                } else {
                    if (isNaN(range[0])) {
                        // `-500` means taking last 500 bytes
                        start = endPos - range[1] + 1;
                        end = endPos;
                    } else {
                        start = range[0];
                        end = range[1];
                    }
                }
                if (end > endPos) {
                    end = endPos;
                }

                return [start, end, end - start + 1];
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    // download
    runtime.registerEXHandler(HTTP_METHODS.GET, /Translayer\/Bank\.CasualStream\/stream/i,
    function (urlInfo, headers) {
        var handle = urlInfo.queryParams['handle'];

        if (handle) {
            var file = pool[handle];
            if (!file) {
                var [session, fileID] = self._parseStorageID(handle);
                file = self._loadConnectionByID(session, fileID, false);

                if (file === null) {
                    return {
                        code: HTTP_STATUS_CODE.notFound
                    };
                }
            }

            var size = file.size();
            var rangeInfo = tryGetRange(headers, size - 1);

            var buffer, code, rspHeaders;
            if (rangeInfo) {
                file.seek(rangeInfo[0]);
                buffer = file.read(rangeInfo[2]);
                rspHeaders = {
                    'Content-Type': MIME_TABLE['binary'],
                    'Content-Length': buffer.length,
                    'Content-Range': `bytes ${rangeInfo[0]}-${rangeInfo[0] + buffer.length - 1}/${size}`
                };

                code = HTTP_STATUS_CODE.partialContent;
            } else {
                file.seekToStart();
                buffer = file.read();
                rspHeaders = {
                    'Content-Type': MIME_TABLE['binary'],
                    'Content-Length': buffer.length
                };

                code = HTTP_STATUS_CODE.success;
            }

            file.close();

            // set file name if given
            var filename = urlInfo.queryParams['filename'];
            if (filename) {
                rspHeaders['Content-Disposition'] = `attachment; filename="${encodeURIComponent(filename)}"`;
            }

            return {
                code: code,
                headers: rspHeaders,
                data: buffer
            };
        } else {
            return {
                code: HTTP_STATUS_CODE.notFound
            };
        }
    });

    return this;
};



module.exports = LindgeCasualStreamPlugin;