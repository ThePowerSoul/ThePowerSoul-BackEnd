#### lindge-casualstream

本地环境模拟`CasualStream` 服务，包括真实的上传和下载机制

__方法__

`setStorageRoot(root: String) -> this`

设置用于存放资源文件的目录
