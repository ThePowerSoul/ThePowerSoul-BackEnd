#### lindge-dev-cross-site

该扩展会自动进行如下配置：

1. 将提供的 `devRoot` 目录映射到虚路径 `\views`
2. 添加一个对资源文件请求的拦截器，如果请求的文件不在当前站点下，会自动到devRoot中可能的目录下查找
3. 支持的搜索目录
   * subpages
   * dialogs
   * uicontrols
   * templates
   * images


__构造参数__

`devRoot: String`

开发环境中映射发布环境的'Views'目录的根目录，一般是项目目录下 `Source/Specified`。
该属性可选，如果没有在构造时提供，可以通过 `setDevRoot` 方法配置。
激活插件时如果没有设置devRoot则会产生异常。


__方法__

`setDevRoot(devRoot: String) -> this`

配置devRoot，作用同构造参数devRoot

`addSite(name: String) -> this`

添加新搜索站点

#### 示例

```javascript
plugins.load('lindge-dev-cross-site', 'D:/myworkspace/devtfs/Develop/Modifications/PlayerL3_UI/Source/Specified')
    .active(runtime);
```