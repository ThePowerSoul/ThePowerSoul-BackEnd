const util = require('util');
const fs = require('fs');
const path = require('path');

const glob = require('glob');
const chalk = require('chalk');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;
const MIME_TYPES = miniserver.MIME_TABLE;


/**
 * list of sites to search
 *
 * @type {Array<String>}
 */
const SITES = ['Social', 'Teaching', 'Exam'];

/**
 * list of sites' sub directories that will be searched
 *
 * @type {Array<String>}
 */
const SUPPORT_SUBDIRS = ['subpages', 'dialogs', 'uicontrols', 'templates', 'images'];

const ROOT_MASK = '/views';


/**
 * create storage structure for glob querying
 *
 * @param {Array<String>} subdirs
 *
 * @returns {Object}
 */
function createSubdirMapping (subdirs) {
    var mapping = {};
    for (let subdir of subdirs) {
        mapping[subdir] = null;
    }

    return mapping;
}

/**
 * @param {String} devRoot  root directory during developing
 *
 * @constructor
 */
function DevPlayL3UICfgPlugin (devRoot) {
    this._devRoot = null;
    this._files = {};
    this._globCache = createSubdirMapping(SUPPORT_SUBDIRS);

    if (arguments.length > 0) {
        this.setDevRoot(devRoot);
    }

    var warning = chalk.yellow("Warning: plugin PlayL3UI is deprecated and will not be maintained, use 'lindge-dev-cross-site' instead\n");
    process.stdout.write(warning);
}

util.inherits(DevPlayL3UICfgPlugin, PluginBase);

DevPlayL3UICfgPlugin.prototype.setDevRoot = function(devRoot) {
    if (typeof devRoot != 'string') {
        throw new TypeError("Dev root must be string");
    }

    if (devRoot.length === 0) {
        devRoot = '/';
    }

    this._devRoot = path.resolve(devRoot);
    return this;
};

/**
 * @param {String} subdir
 * @param {String} filename
 *
 * @returns {?String}
 */
DevPlayL3UICfgPlugin.prototype._findByGlob = function(subdir, filename) {
    var globCache = this._globCache;
    var cache;
    if (globCache[subdir] !== null) {
        cache = globCache[subdir];
    } else {
        cache = {};
        for (let site of SITES) {
            let pattern = `/${site}/**/${subdir}/*`;
            let result = glob.sync(pattern, { root: this._devRoot, absolute: true });
            // write cache
            for (let fpath of result) {
                cache[path.basename(fpath)] = fpath;
            }
        }

        globCache[subdir] = cache;
    }

    return cache.hasOwnProperty(filename) ? cache[filename] : null;
};

/**
 * @param {String} subdir
 * @param {String} filename
 *
 * @returns {?String}
 */
DevPlayL3UICfgPlugin.prototype._findFile = function(subdir, filename) {
    var key = [subdir, filename].join('/');
    var cache = this._files;
    if (cache.hasOwnProperty(key)) {
        return cache[key];
    } else {
        var fpath = this._findByGlob(subdir, filename);
        if (fpath !== null) {
            cache[key] = fpath;
        }

        return fpath;
    }
};

/**
 * @param {String} fpath
 * @returns {Buffer}
 */
DevPlayL3UICfgPlugin.prototype._readFile = function(fpath) {
    return fs.readFileSync(fpath, { flag: 'r', encoding: null });
};

DevPlayL3UICfgPlugin.prototype.active = function(runtime) {
    if (this._devRoot === null) {
        throw new Error("Dev root is not set");
    }

    runtime.setVirtualDirectory(ROOT_MASK, this._devRoot);

    var self = this;

    var acceptDirs = SUPPORT_SUBDIRS.join('|');
    var pathPattern = new RegExp(`/(${acceptDirs})/([^/\\s]+)$`, 'i');

    var notFoundResult = {
        code: HTTP_STATUS_CODE.notFound,
        headers: {
            'Content-Type': 'text/plain'
        }
    };

    runtime.registerEXHandler(HTTP_METHODS.GET, pathPattern, function (urlInfo, headers, body, parts) {
        var reqPath = urlInfo.pathname;

        var fpath = self._findFile(parts[0], parts[1]);
        if (fpath) {
            var ext = path.extname(fpath).substr(1);
            var contentType = MIME_TYPES[ext] || MIME_TYPES['binary'];

            var fileData = self._readFile(fpath);
            return {
                code: HTTP_STATUS_CODE.success,
                data: fileData,
                headers: {
                    'Content-Type': contentType,
                    'Content-Length': fileData.length
                }
            };
        } else {
            return notFoundResult;
        }
    });

    return this;
};


module.exports = DevPlayL3UICfgPlugin;