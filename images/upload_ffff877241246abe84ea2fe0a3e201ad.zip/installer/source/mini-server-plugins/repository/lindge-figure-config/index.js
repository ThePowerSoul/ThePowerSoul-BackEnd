const util = require('util');
const fs = require('fs');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;

const LindgeRouteTablePlugin = require('../lindge-route-table');
const LindgeFigureConfigAngularPlugin = require('../lindge-figureconfig-angular');
const LindgeFigureConfigRedirectPlugin = require('../lindge-figureconfig-redirect');

const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


/**
 * @param {Object} obj
 * @param {String} propName
 */
function defineReadonlyProp (obj, propName) {
    var privatekey = '_' + propName;

    function setter (value) {
        return;
    }

    function getter () {
        return this[privatekey];
    }

    obj.__defineGetter__(propName, getter);
    obj.__defineSetter__(propName, setter);
}


function LindgeFigureConfigPlugin() {
    PluginBase.call(this, 'lindge-figure-config');

    this._routeTable = new LindgeRouteTablePlugin();
    this._configSection = new LindgeFigureConfigAngularPlugin();
    this._redirect = new LindgeFigureConfigRedirectPlugin();
}

util.inherits(LindgeFigureConfigPlugin, PluginBase);

defineReadonlyProp(LindgeFigureConfigPlugin.prototype, 'routeTable');
defineReadonlyProp(LindgeFigureConfigPlugin.prototype, 'configSection');
defineReadonlyProp(LindgeFigureConfigPlugin.prototype, 'redirect');

LindgeFigureConfigPlugin.prototype.active = function(runtime) {
    this._routeTable.active(runtime);
    this._configSection.active(runtime);
    this._redirect.active(runtime);

    return this;
};


module.exports = LindgeFigureConfigPlugin;