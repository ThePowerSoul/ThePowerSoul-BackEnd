#### lindge-figure-config

Figure.Config相关控制器统一配置扩展，可以一次性加载`lindge-route-table`、`lindge-figureconfig-angular`、`lindge-figureconfig-redirect`三个扩展

__属性__

`routeTable`

lindge-route-table扩展的实例

`configSection`

lindge-figureconfig-angular扩展的实例

`redirect`

lindge-figureconfig-redirect扩展的实例