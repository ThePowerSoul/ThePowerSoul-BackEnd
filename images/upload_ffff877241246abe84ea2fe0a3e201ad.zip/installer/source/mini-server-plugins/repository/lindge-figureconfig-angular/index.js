const util = require('util');
const fs = require('fs');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


/**
 * test whether the given path is a file
 *
 * @param {String} fpath
 * @returns {Boolean}
 */
function fileExists (fpath) {
    try {
        return fs.statSync(fpath).isFile();
    } catch (e) {
        return false;
    }
}


/**
 * config section model
 *
 * @constructor
 *
 * @param {any} src data source
 * @param {Boolean=} fromFile whether the given data src is file path
 */
function ConfigSection (src, fromFile) {
    this._src = src;
    this._cache = null;
    this._fromFile = !!fromFile;
}

/**
 * @returns {String}
 */
ConfigSection.prototype._readSrcAsFile = function() {
    if (fileExists(this._src)) {
        return fs.readFileSync(this._src, { encoding: 'utf8' });
    } else {
        return "null";
    }
};

/**
 * @returns {String}
 */
ConfigSection.prototype._readSrcAsJSObject = function() {
    try {
        return JSON.stringify(this._src);
    } catch (e) {
        return "null";
    }
};

/**
 * convert config section to javascript code fragment
 *
 * @returns {String}
 */
ConfigSection.prototype.toJSFragment = function() {
    if (this._cache === null) {
        if (this._fromFile) {
            this._cache = this._readSrcAsFile();
        } else {
            this._cache = this._readSrcAsJSObject();
        }

        return this._cache;
    } else {
        return this._cache;
    }
};


/**
 * plugin class
 */
function LindgeFigureConfigAngularPlugin () {
    PluginBase.call(this, 'lindge-figureconfig-angular');

    this._configSections = {};
    this._cache = {};

    this._baseModuleName = 'Figure-Config-ConfigSection';
    this._configCodeTemplate = '.constant(\'{moduleName}\', {data})';
    this._urlMatcher = /Translayer\/Figure.Config\/Angular\/ConfigSection/i;
}

util.inherits(LindgeFigureConfigAngularPlugin, PluginBase);

/**
 * register a new config section
 *
 * @param {String} name name of the config section
 * @param {Any} dataSrc
 * @param {Boolean=} fromFile
 */
LindgeFigureConfigAngularPlugin.prototype.addConfigSection = function (name, dataSrc, fromFile) {
    if (arguments.length < 2) {
        throw new Error("Data src is null");
    }

    if (typeof name !== 'string' || name.length === 0) {
        throw new Error("Invalid config section name");
    }

    var configSection = new ConfigSection(dataSrc, fromFile);
    this._configSections[name] = configSection;

    return this;
};

/**
 * @param {Object} params
 * @return {String}
 */
LindgeFigureConfigAngularPlugin.prototype._hashQuery = function(params) {
    var queryKeys = Object.keys(params);
    return queryKeys.sort().map((key) => `${key}=${params[key]}`).join('|');
};

/**
 * @param {Object} params
 * @return {String}
 */
LindgeFigureConfigAngularPlugin.prototype._generateCode = function(params) {
    var header = `angular.module('${this._baseModuleName}', [])`;
    var template = this._configCodeTemplate;

    var codeBlocks = [header];
    for (let name of Object.keys(params)) {
        let configName = params[name];
        if (this._configSections.hasOwnProperty(configName)) {
            let configSection = this._configSections[configName];
            let code = template.replace(/\{\s*(\w+?)\s*\}/g, function (match, key) {
                switch (key) {
                    case 'moduleName':
                        return name;
                    case 'data':
                        return configSection.toJSFragment();
                    default:
                        return '';
                }
            });

            codeBlocks.push(code);
        }
    }

    codeBlocks.push(';');
    return codeBlocks.join('');
};

LindgeFigureConfigAngularPlugin.prototype.active = function(runtime) {
    var self = this;
    runtime.registerEXHandler(HTTP_METHODS.GET, this._urlMatcher, function (urlInfo, headers) {
        var queryParams = urlInfo.queryParams;
        var hash = self._hashQuery(queryParams);

        var data;
        if (self._cache.hasOwnProperty(hash)) {
            data = self._cache[hash];
        } else {
            data = Buffer.from(self._generateCode(queryParams), 'utf8');
            self._cache[hash] = data;
        }

        return {
            code: HTTP_STATUS_CODE.success,
            headers: {
                'Content-Type': 'application/javascript; charset=utf-8',
                'Content-Length': data.length
            },
            data: data
        };
    });

    return this;
};


module.exports = LindgeFigureConfigAngularPlugin;