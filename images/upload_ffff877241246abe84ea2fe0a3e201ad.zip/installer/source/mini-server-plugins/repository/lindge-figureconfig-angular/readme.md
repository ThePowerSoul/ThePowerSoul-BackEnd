#### lindge-figureconfig-angular

该扩展用于程序化模拟`figure.config/angular`服务

__方法__

`addConfigSection(name: String, dataSrc: any, fromFile: Boolean = false) -> this`

添加一个配置项

* name：配置项名，必须为非空字符串
* dataSrc：配置源，可以是任意JS对象或一个JSON文件路径
* fromFile：指定dataSrc是否为文件路径

#### 示例

```javascript
plugins.load('lindge-figureconfig-angular')
    .addConfigSection('BasicQuestionTypes',
        [{
            "Name": "通用（选择、填空、简答）",
            "Code": "Common.General"
        }, {
            "Name": "选词填空",
            "Code": "Common.BankedCloze"
        }, {
            "Name": "完形填空",
            "Code": "Common.Cloze"
        }, {
            "Name": "匹配",
            "Code": "Common.Matching"
        }, {
            "Name": "作文",
            "Code": "Common.Writing"
        }, {
            "Name": "录音题",
            "Code": "Common.Record"
        }])
    .active(runtime);
```

添加上述配置后通过请求`/Translayer/Figure.Config/Angular/ConfigSection?questionTypes=BasicQuestionTypes`就可以返回如下的脚本

```javascript
angular.module('Figure.Config', [])
    .constant('questionTypes',
        [{
            "Name": "通用（选择、填空、简答）",
            "Code": "Common.General"
        }, {
            "Name": "选词填空",
            "Code": "Common.BankedCloze"
        }, {
            "Name": "完形填空",
            "Code": "Common.Cloze"
        }, {
            "Name": "匹配",
            "Code": "Common.Matching"
        }, {
            "Name": "作文",
            "Code": "Common.Writing"
        }, {
            "Name": "录音题",
            "Code": "Common.Record"
        }]);
```