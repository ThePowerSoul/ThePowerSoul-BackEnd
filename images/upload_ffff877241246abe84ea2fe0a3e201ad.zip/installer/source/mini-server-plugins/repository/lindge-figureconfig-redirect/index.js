const util = require('util');
const url = require('url');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


/**
 * plugin class
 */
function LindgeFigureConfigRedirectPlugin () {
    PluginBase.call(this, 'lindge-figureconfig-redirect');

    this._routeMapping = {};
    this._urlMatcher = /Translayer\/Figure\.Config\/api\/Redirect/i;
}

util.inherits(LindgeFigureConfigRedirectPlugin, PluginBase);

/**
 * add an entrance
 *
 * @param {String} routeName
 * @param {String} targetUrl
 */
LindgeFigureConfigRedirectPlugin.prototype.addEntranceRouter = function (routeName, targetUrl) {
    if (routeName.length < 1) {
        throw new Error("Invalid route name");
    }

    if (!routeName.startsWith('Entrance.')) {
        routeName = 'Entrance.' + routeName;
    }

    var urlInfo = url.parse(targetUrl);
    if (urlInfo.pathname) {
        // get rid of url components
        urlInfo.query = null;
        urlInfo.search = null;
        urlInfo.hash = null;
        urlInfo.href = null;
        this._routeMapping[routeName] = url.format(urlInfo);
    } else {
        throw new Error("Invalid url " + targetUrl);
    }

    return this;
};

LindgeFigureConfigRedirectPlugin.prototype._findByRouteName = function(routeName) {
    if (!routeName.startsWith('Entrance.')) {
        routeName = 'Entrance.' + routeName;
    }

    var routeMapping = this._routeMapping;
    if (routeMapping.hasOwnProperty(routeName)) {
        return routeMapping[routeName];
    } else {
        return null;
    }
};

LindgeFigureConfigRedirectPlugin.prototype.active = function(runtime) {
    var self = this;

    var notFoundResult = {
        code: HTTP_STATUS_CODE.notFound,
    };

    runtime.registerEXHandler(HTTP_METHODS.GET, this._urlMatcher, function (urlInfo, headers) {
        var pathTpl = urlInfo.queryParams.entrance;
        if (pathTpl) {
            var entranceInfo = url.parse(pathTpl);
            var routeName = entranceInfo.pathname;

            var targetUrl = self._findByRouteName(routeName);
            if (targetUrl !== null) {
                entranceInfo.pathname = targetUrl;
                var redirectTarget = url.format(entranceInfo);

                return {
                    code: HTTP_STATUS_CODE.movedPermanently,
                    headers: {
                        'Cache-Control': 'no-cache',
                        'Location': redirectTarget
                    }
                };
            } else {
                return notFoundResult;
            }
        } else {
            return notFoundResult;
        }
    });

    return this;
};


module.exports = LindgeFigureConfigRedirectPlugin;