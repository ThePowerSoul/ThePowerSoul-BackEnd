#### lindge-figureconfig-redirect

该扩展用于程序化模拟`figure.config/redirect`服务

__方法__

`addEntranceRouter(routeName: String, targetUrl: String) -> this`

注册一个entrance路由

* routeName：路由名，可以带有可选的'Entrance.'前缀
* targetUrl：目标url，不带querystring和hash部分（如果存在自动移除）

