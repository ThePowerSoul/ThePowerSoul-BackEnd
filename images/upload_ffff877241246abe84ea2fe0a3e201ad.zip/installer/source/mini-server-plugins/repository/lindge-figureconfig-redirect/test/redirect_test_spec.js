var redirectPlugin = require('../index.js');

const miniserver = require('mini-server-core');
const HTTP_METHODS = miniserver.HTTP_METHODS;
const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;


describe("test redirect", function () {
    var plugin;
    beforeEach(function () {
        plugin = new redirectPlugin();
    });

    function extractEntranceMapping (plugin) {
        return plugin._routeMapping;
    }

    it("test entrance registration", function () {
        plugin.addEntranceRouter('Entrance.Views.Site1', '/views/site1/index.html');
        plugin.addEntranceRouter('Views.Site2', '/views/site2/index.html');

        expect(extractEntranceMapping(plugin)).toEqual({
            'Entrance.Views.Site1': '/views/site1/index.html',
            'Entrance.Views.Site2': '/views/site2/index.html'
        });
    });

    it("test entrance registration with url resolving", function () {
        plugin.addEntranceRouter('Entrance.Views.Site1', '/views/site1/index.html?foo=bar#/sha');

        expect(extractEntranceMapping(plugin)).toEqual({
            'Entrance.Views.Site1': '/views/site1/index.html'
        });
    });

    it("test redirecting", function () {
        var mockRuntime = {
            handlers: {},
            registerEXHandler: function (method, matcher, handler) {
                this.handlers[method] = {
                    matcher: matcher,
                    handler: handler
                };
            }
        };

        plugin.addEntranceRouter('Entrance.Views.Site1', '/views/site1/index.html')
            .addEntranceRouter('Views.Site2', '/views/site2/index.html')
            .active(mockRuntime);

        expect(mockRuntime.handlers.hasOwnProperty(HTTP_METHODS.GET)).toBe(true);

        var handler = mockRuntime.handlers[HTTP_METHODS.GET];
        expect(handler.matcher.test('/Translayer/Figure.Config/api/Redirect?entrance=xxx')).toBe(true);

        var result_1 = handler.handler({
            queryParams: {
                entrance: 'Views.Site1?id=111&class=foo#/review'
            }
        });

        expect(result_1).toEqual({
            code: HTTP_STATUS_CODE.movedPermanently,
            headers: jasmine.objectContaining({
                Location: '/views/site1/index.html?id=111&class=foo#/review'
            })
        });

        var result_2 = handler.handler({
            queryParams: {
                entrance: 'Views.Site3?id=111&class=foo#/review'
            }
        });

        expect(result_2).toEqual({
            code: HTTP_STATUS_CODE.notFound
        });
    });
});