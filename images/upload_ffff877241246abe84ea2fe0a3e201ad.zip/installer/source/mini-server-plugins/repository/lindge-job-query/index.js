const util = require('util');
const fs = require('fs');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


const JOB_STATES = {
    waitexecute: 'waitexecute',
    executing: 'executing',
    successful: 'successful',
    failed: 'failed'
};

function isValueInRange (val, min, max) {
    return val >= min && val <= max;
}

function isValidID (id) {
    return typeof id == 'string' && id.length > 0;
}


const JOB_POST_EXECUTION_ACTIONS = {
    keep: 1,
    cycle: 2
};

/**
 * a task represents a single life cycle of an execution task
 *
 * @param {String} targetState
 * @param {Number} targetProgress
 * @param {Number} estimateBatch
 *
 * @constructor
 *
 */
function ExecutionTask (jobInfo, targetState, targetProgress, estimateBatch) {
    targetProgress = Number(targetProgress);
    estimateBatch = Math.round(estimateBatch);

    if (!JOB_STATES.hasOwnProperty(targetState)) {
        throw new Error("Invalid state: " + targetState);
    }
    if (isNaN(targetProgress)) {
        throw new TypeError("Invalid progress");
    }
    if (!isValueInRange(targetProgress, 0, 100)) {
        throw new RangeError("Invalid progress");
    }
    if (isNaN(estimateBatch)) {
        throw new TypeError("Invalid batch");
    }
    if (!isValueInRange(estimateBatch, 0, 100)) {
        throw new RangeError("Invalid batch");
    }


    this.state = targetState;
    this.progress = Number(targetProgress);
    this.step = Math.round((targetProgress - jobInfo.Progress) / estimateBatch);

    this._snapshoot = null;
    this._postAction = JOB_POST_EXECUTION_ACTIONS.keep;
    this._finishQueue = [];
}

ExecutionTask.prototype = {
    /**
     * @type {Object}
     */
    get snapshoot() {
        return this._snapshoot;
    },
    set snapshoot(value) {
        return;
    },

    /**
     * @type {Number}
     */
    get postAction() {
        return this._postAction;
    },
    set postAction(value) {
        return;
    }
};

/**
 * @param {Object} snapshoot
 */
ExecutionTask.prototype.setSnapshoot = function(snapshoot) {
    if (typeof snapshoot == 'object') {
        this._snapshoot = snapshoot;
        return this;
    } else {
        throw new TypeError("Snapshoot must be object");
    }
};

ExecutionTask.prototype.setPostAction = function(action) {
    if (typeof action == 'number') {
        this._postAction = action;
        return this;
    } else {
        throw new TypeError("Invalid post action");
    }
};

/**
 * @param {function} handler
 */
ExecutionTask.prototype.then = function(handler) {
    if (typeof handler == 'function') {
        this._finishQueue.push(handler);
        return this;
    } else {
        throw new TypeError("Handler must be function");
    }
};

ExecutionTask.prototype.executeFinishHandlers = function() {
    var queue = this._finishQueue;
    while (queue.length > 0) {
        queue.shift()();
    }
};

/**
 * data structure for job
 */
function JobInfo () {
    this.AliasName = '';
    this.JobID = '';
    this.CurrentStep = '';
    this.Progress = 0;
    this.JobDescription = '';
    this.Exception = '';
    this.ExecutedTime = new Date();
    this.State = JOB_STATES.waitexecute;
    this.User = '';

    this._executeTask = null;
    this._fileLink = null;
}

/**
 * update state
 *
 * @param {String} state  state name
 * @returns {JobInfo}
 */
JobInfo.prototype.setState = function(state) {
    if (JOB_STATES.hasOwnProperty(state)) {
        this.State = JOB_STATES[state];
    } else {
        this.State = JOB_STATES['waitexecute'];
    }

    return this;
};

/**
 * @param {Number} progress
 * @returns {JobInfo}
 */
JobInfo.prototype.setProgress = function(progress) {
    if (isNaN(progress)) {
        this.Progress = 0;
    } else {
        progress = Number(progress);
        if (progress < 0) {
            progress = 0;
        } else if (progress > 100) {
            progress = 100;
        }

        this.Progress = progress;
    }

    return this;
};

/**
 * @param {Object} obj
 * @returns {JobInfo}
 */
JobInfo.prototype.fromPlainObj = function(obj) {
    var strFields = ['AliasName', 'JobID', 'CurrentStep', 'JobDescription', 'Exception', 'User'];
    for (var i = 0; i < strFields.length; i++) {
        var fieldName = strFields[i];
        if (obj.hasOwnProperty(fieldName)) {
            this[fieldName] = String(obj[fieldName]);
        }
    }

    if (obj.hasOwnProperty('State')) {
        this.setState(obj['State']);
    }

    if (obj.hasOwnProperty('Progress')) {
        this.setProgress(obj['Progress']);
    }

    if (obj.hasOwnProperty('ExecutedTime')) {
        this.ExecutedTime = new Date(obj['ExecutedTime']);
    }

    return this;
};

/**
 * @returns {Object}
 */
JobInfo.prototype.toPlainObj = function () {
    var obj = {};
    var fields = ['AliasName', 'JobID', 'CurrentStep', 'Progress', 'JobDescription', 'Exception', 'ExecutedTime', 'User', 'State'];
    for (var i = 0; i < fields.length; i++) {
        var field = fields[i];
        obj[field] = this[field];
    }

    return obj;
};

/**
 * @returns {Boolean}
 */
JobInfo.prototype.isValid = function() {
    return isValidID(this.AliasName) && isValidID(this.JobID);
};

/**
 * @returns {JobInfo}
 */
JobInfo.prototype.makeSuccess = function () {
    this.Progress = 100;
    this.State = JOB_STATES.successful;

    return this;
};

/**
 * @param {String} exception
 * @returns {JobInfo}
 */
JobInfo.prototype.makeFailed = function(exception) {
    this.Exception = exception || '';
    this.State = JOB_STATES.failed;

    return this;
};

/**
 * @param {String} targetState
 * @param {Number} targetProgress
 * @param {Number} estimateBatch
 *
 * @returns {JobInfo}
 */
JobInfo.prototype.setExecutionTask = function (targetState, targetProgress, estimateBatch) {
    if (this._executeTask === null) {
        var task = new ExecutionTask(this, targetState, targetProgress, estimateBatch);
        task.setSnapshoot(this.toPlainObj());
        this._executeTask = task;
        return task;
    } else {
        return null;
    }
};

/**
 * @param {String} fpath  file path
 */
JobInfo.prototype.setFileLink = function(fpath) {
    this._fileLink = fpath;
    return this;
};

/**
 * update execution task or file link by once
 *
 * @returns {JobInfo}
 */
JobInfo.prototype.notify = function () {
    var executeTask = this._executeTask;
    var fileLink = this._fileLink;

    if (fileLink !== null) {
        try {
            var fileData = fs.readFileSync(fileLink, { flag: 'r', encoding: miniserver.DEFAULT_TEXT_ENCODING });
            var jsonObj = JSON.parse(fileData);

            var jobConfig = null;
            if (Array.isArray(jsonObj)) {
                for (var i = 0; i < jsonObj.length && jobConfig === null; i++) {
                    var cfg = jsonObj[i];
                    if (cfg.AliasName && cfg.AliasName === this.AliasName) {
                        jobConfig = cfg;
                    }
                }
            } else {
                jobConfig = jsonObj;
            }

            if (jobConfig !== null) {
                this.fromPlainObj(jobConfig);
            }
        } catch (err) {
            if (err.code != 'ENONET') {
                throw err;
            }
        }
    } else if (executeTask !== null) {
        if (this.State == executeTask.state && this.Progress == executeTask.progress) {
            if (executeTask.postAction == JOB_POST_EXECUTION_ACTIONS.cycle) {
                var snapshoot = executeTask.snapshoot;
                if (snapshoot) {
                    this.fromPlainObj(snapshoot);
                } else {
                    this._executeTask = null;
                }
            } else {
                this._executeTask = null;
            }

            executeTask.executeFinishHandlers();
        } else {
            this.State = JOB_STATES.executing;
            var newProgress = Math.min(this.Progress + executeTask.step, executeTask.progress);
            if (newProgress == executeTask.progress) {
                this.State = JOB_STATES[executeTask.state];
            }

            this.setProgress(newProgress);
            this.ExecutedTime = new Date();
        }
    }

    return this;
};


/**
 * plugin
 */
function LindgeJobQueryPlugin () {
    PluginBase.call(this, 'lindge-job-query');
    this._jobRepo = {};
}

util.inherits(LindgeJobQueryPlugin, PluginBase);

LindgeJobQueryPlugin.prototype.__defineGetter__('states', function () {
    return JOB_STATES;
});

LindgeJobQueryPlugin.prototype.__defineSetter__('states', function (value) {
    return;
});

LindgeJobQueryPlugin.prototype.__defineGetter__('executionPostActions', function () {
    return JOB_POST_EXECUTION_ACTIONS;
});

LindgeJobQueryPlugin.prototype.__defineSetter__('executionPostActions', function (value) {
    return;
});

LindgeJobQueryPlugin.prototype._addToRepo = function(jobInfo) {
    this._jobRepo[jobInfo.AliasName] = jobInfo;
};

/**
 * load job configuration from a json file
 *
 * @param {String} fpath  file path
 * @returns {LindgeJobQueryPlugin}
 */
LindgeJobQueryPlugin.prototype.loadFromFile = function(fpath) {
    var fileContent = fs.readFileSync(fpath, { flag: 'r', encoding: miniserver.DEFAULT_TEXT_ENCODING });
    var jsonObj = JSON.parse(fileContent);

    if (Array.isArray(jsonObj)) {
        for (var i = 0; i < jsonObj.length; i++) {
            var jobInfo = new JobInfo();
            jobInfo.fromPlainObj(jsonObj[i]);

            if (jobInfo.isValid()) {
                this._addToRepo(jobInfo);
            }
        }
    } else {
        throw new TypeError("Job configuration must be array");
    }
};

LindgeJobQueryPlugin.prototype.addFileLink = function(fpath) {
    //
};

/**
 * @param {String} alias  alias of the job
 * @returns {?JobInfo}
 */
LindgeJobQueryPlugin.prototype.getJobInfo = function(alias) {
    var repo = this._jobRepo;
    if (repo.hasOwnProperty(alias)) {
        return repo[alias];
    } else {
        return null;
    }
};

/**
 * create a new job and add it to the repository
 *
 * @param {String} alias
 * @param {String} id
 *
 * @returns {JobInfo}
 */
LindgeJobQueryPlugin.prototype.createJob = function (alias, id) {
    if (isValidID(alias) && isValidID(id)) {
        var jobInfo = new JobInfo();
        jobInfo.AliasName = alias;
        jobInfo.JobID = id;

        this._jobRepo[alias] = jobInfo;
        return jobInfo;
    } else {
        throw new Error("Alias name and job id must be not-empty string");
    }
};

/**
 * remove a job from the repository by alias name
 *
 * @param {String} alias
 */
LindgeJobQueryPlugin.prototype.removeJob = function (alias) {
    if (this._jobRepo.hasOwnProperty(alias)) {
        delete this._jobRepo[alias];
    }
};

LindgeJobQueryPlugin.prototype.active = function(runtime) {
    var self = this;

    // get method
    runtime.registerEXHandler(HTTP_METHODS.GET, /Translayer\/Engine\.Alias\.Query\/api\/JobAliasQuery\/(.+)/i,
    function (urlInfo, headers, body, matchers) {
        var jobInfo = null;
        var alias = matchers[0];
        jobInfo = self.getJobInfo(alias);
        if (jobInfo !== null) {
            jobInfo.notify();
        }

        var bufferData = miniserver.encodeJSON(jobInfo === null ? null : jobInfo.toPlainObj());
        return {
            code: HTTP_STATUS_CODE.success,
            data: bufferData,
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': bufferData.length
            }
        };
    });

    // post method
    runtime.registerEXHandler(HTTP_METHODS.POST, /Translayer\/Engine\.Alias\.Query\/api\/JobAliasQuery\b/i,
    function (urlInfo, headers, body) {
        var result = {};
        if (Array.isArray(body)) {
            for (var i = 0; i < body.length; i++) {
                var alias = body[i];
                var jobInfo = self.getJobInfo(alias);
                result[alias] = (jobInfo === null) ? null : jobInfo.notify().toPlainObj();
            }
        }

        var bufferData = miniserver.encodeJSON(result);
        return {
            code: HTTP_STATUS_CODE.success,
            data: bufferData,
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': bufferData.length
            }
        };
    });

    return this;
};


module.exports = LindgeJobQueryPlugin;