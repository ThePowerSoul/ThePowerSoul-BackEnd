#### lindge-job-query

模拟Job查询服务，提供可配置的Job状态管理功能


__方法__

`loadFromFile(fpath: String)`

从一个配置文件中加载一组Job，配置文件为JSON类型，如：
```json
[{
    "AliasName": "job1",
    "JobID": "job1",
    "Progress": 25,
    "JobDescription": "xxxxx",
    "ExecutedTime": "2015-10-4 14:22:20",
    "State": "executing"
}, {
    "AliasName": "job2",
    "JobID": "job2",
    "Progress": 60,
    "CurrentStep": "Step6",
    "JobDescription": "xxxxx",
    "Exception": "something happened",
    "State": "failed"
}]
```

`getJobInfo(alias: String) -> JobInfo`

根据Alias获取Job，如果Job不存在返回null，JobInfo为内置的Job信息对象

`createJob(alias: String, id: String) -> JobInfo`

创建一个Job并添加到内置仓库中，参数为Job的别名和ID（必须是非空字符串），返回创建的Job对象

`removeJob(alias: String)`

从内置仓库中移除指定alias名关联的Job


#### JobInfo

内置的Job数据结构，提供对Job状态的精细控制

__属性__

`AliasName: String`

Job别名

`JobID: String`

Job标识

`CurrentStep: String`

当前步骤

`Progress: Number`

当前进度

`JobDescription: String`

描述信息

`Exception: String`

Job失败后的异常信息

`ExecutedTime: Date`

Job最后一次激活的时间

`State: String`

状态，可选项有：
* waitexecute
* executing
* successful
* failed

`User: String`

用户

__方法__

`setState(state: String) -> this`

设置Job状态，`state`必须是上述几种状态之一，如果不能识别，自动设置为`waitexecute`

`setProgress(progress： Number) -> this`

设置进度值，progress取值范围是[0, 100]，如果超出自动截除

`fromPlainObj(obj: Object) -> this`

从一个纯JS对象同步内部属性，作为参数的对象必须有和JobInfo相同的属性，可用来批量更新属性

`toPlainObj() -> Object`

转换为一个纯JS对象，用来序列化

`makeSuccess() -> this`

将当前Job变为成功状态，调用后`State`属性会变为`successful`，`Progress`属性会变为100

`makeFailed(exception?: String) -> this`

将当前Job变为失败状态，调用后`State`属性会变为`failed`，如果提供了参数`exception`，会更新`Exception`属性

`setExecutionTask(targetState: String, targetProgress: Number, estimateBatch: Number) -> ExecutionTask`

配置一个执行任务，用于指定该Job在若干次查询后逐渐过渡到某一状态

* `targetState`: 目标状态
* `targetProgress`: 期望Job的最终进度，当Job的进度达到该值时会更新内部状态为`targetState`，否则状态为executing
* `estimateBatch`: 期望Job经过若干次查询后变为指定状态的步数

`setFileLink(fpath: String) -> this`

建立一个文件链接，每次查询该Job时都会读取指定文件中的配置更新Job信息。配置文件为json格式，可以是一个对象，也可以是数组（Job对象列表，通过AliasName匹配）


#### ExecutionTask

执行任务类

__属性__

`snapshoot: Object?`

Job状态快照对象

`postAction: Number`

执行任务完成后进行的操作类型枚举，可以通过插件对象的 `executionPostActions` 获取，可选项有

* `keep` 保持Job在任务执行完成时的状态
* `cycle` 将Job状态重置为快照所表示的状态，并重新执行一轮(必须配置了快照)

__方法__

`setSnapshoot(snapshoot: Object) -> this`

设置快照，通过 `JobInfo` 创建时任务时会自动使用Job当前的状态设置快照，因此一般不需要手动调用

`setPostAction(action: Number) -> this`

设置任务完成后进行的操作类型，参数为 `executionPostActions` 枚举

`then(handler: Function) -> this`

添加一个执行任务完成后执行的句柄


#### 示例

```javascript
var jobRepository = plugins.load('lindge-job-query');

jobRepository.createJob('job1', 'job1')
    .fromPlainObj({
        "Progress": 25,
        "CurrentStep": "",
        "JobDescription": "xxxxx",
        "Exception": "",
        "ExecutedTime": new Date("2015-10-4 14:22:20"),
        "State": "executing"
    });

jobRepository.createJob('job2', 'job2')
    .fromPlainObj({
        "Progress": 60,
        "CurrentStep": "Step6",
        "JobDescription": "xxxxx",
        "Exception": "something happened",
        "State": "failed"
    });

jobRepository.getJobInfo('job1')
    .setExecutionTask('successful', 100, 4)
    .then(function () {
        console.log('Job1 finished!');
    });

jobRepository.active(runtime);
```