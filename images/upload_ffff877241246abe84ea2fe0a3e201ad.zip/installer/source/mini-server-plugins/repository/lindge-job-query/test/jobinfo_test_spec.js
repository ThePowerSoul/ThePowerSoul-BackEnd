const fs = require('fs');
const path = require('path');

var jobPlugin = require('../index.js');


describe("test job info", function () {
    var plugin, jobInfo;
    beforeEach(function () {
        plugin = new jobPlugin();
        jobInfo = plugin.createJob('foo', 'bar');
    });

    it("test set state", function () {
        var states = plugin.states;

        jobInfo.setState('executing');
        expect(jobInfo.State).toBe(states['executing']);

        jobInfo.setState('failed');
        expect(jobInfo.State).toBe(states['failed']);

        jobInfo.setState('null');
        expect(jobInfo.State).toBe(states['waitexecute']);
    });

    it("test set progress", function () {
        jobInfo.setProgress(60);
        expect(jobInfo.Progress).toBe(60);

        jobInfo.setProgress(200);
        expect(jobInfo.Progress).toBe(100);

        jobInfo.setProgress(-100);
        expect(jobInfo.Progress).toBe(0);
    });

    it("test valid testing", function () {
        expect(jobInfo.isValid()).toBeTruthy();

        jobInfo.AliasName = '';
        expect(jobInfo.isValid()).toBeFalsy();
    });

    it("test make success", function () {
        jobInfo.makeSuccess();
        expect(jobInfo.State).toBe(plugin.states.successful);
        expect(jobInfo.Progress).toBe(100);
    });

    it("test make failed", function () {
        jobInfo.setProgress(50);
        jobInfo.makeFailed('xxx');
        expect(jobInfo.State).toBe(plugin.states.failed);
        expect(jobInfo.Exception).toBe('xxx');
        expect(jobInfo.Progress).toBe(50);
    });

    it("test convert form plain object", function () {
        jobInfo.fromPlainObj({
            AliasName: "sha",
            CurrentStep: "Step2",
            Progress: 50,
            JobDescription: "xxxx",
            State: 'executing'
        });

        expect(jobInfo).toEqual(jasmine.objectContaining({
            AliasName: "sha",
            JobID: "bar",
            CurrentStep: "Step2",
            Progress: 50,
            JobDescription: "xxxx",
            State: 'executing'
        }));
    });

    it("test convert to plain object", function () {
        jobInfo.setProgress(60);
        jobInfo.setState('failed');
        jobInfo.CurrentStep = "Step4";
        jobInfo.Exception = 'something happeded';
        jobInfo.JobDescription = 'xxx';

        expect(jobInfo.toPlainObj()).toEqual({
            AliasName: "foo",
            JobID: "bar",
            CurrentStep: "Step4",
            Progress: 60,
            JobDescription: "xxx",
            Exception: "something happeded",
            ExecutedTime: jobInfo.ExecutedTime,
            State: plugin.states[jobInfo.State],
            User: ""
        });
    });

    it("test execution task", function () {
        var task = jobInfo.setExecutionTask('successful', 100, 5);

        jobInfo.notify();
        expect(jobInfo.State).toBe(plugin.states.executing);
        expect(jobInfo.Progress).toBe(20);

        jobInfo.notify();
        expect(jobInfo.State).toBe(plugin.states.executing);
        expect(jobInfo.Progress).toBe(40);

        for (var i = 0; i < 3; i++) {
            jobInfo.notify();
        }

        expect(jobInfo.State).toBe(plugin.states.successful);
        expect(jobInfo.Progress).toBe(100);

        expect(jobInfo._executeTask).not.toBe(null);
        jobInfo.notify();
        expect(jobInfo._executeTask).toBe(null);
    });

    it("test execution task finish queue", function () {
        var callbacks = {
            cb1: function () {return;},
            cb2: function () {return;}
        };

        spyOn(callbacks, 'cb1');
        spyOn(callbacks, 'cb2');

        var task = jobInfo
            .setExecutionTask('successful', 100, 5)
            .then(callbacks.cb1)
            .then(callbacks.cb2);

        for (var i = 0; i < 6; i++) {
            jobInfo.notify();
        }

        expect(callbacks.cb1).toHaveBeenCalled();
        expect(callbacks.cb2).toHaveBeenCalled();
    });

    it("test file link", function () {
        var tempFile = path.join(__dirname, '_temp.json');
        try {
            fs.writeFileSync(tempFile, JSON.stringify({
                AliasName: 'foo',
                JobID: 'bar',
                Progress: 50
            }), { encoding: 'utf8' });

            jobInfo.setFileLink(tempFile);
            jobInfo.notify();

            expect(jobInfo.Progress).toBe(50);

            fs.writeFileSync(tempFile, JSON.stringify([{
                AliasName: 'foo',
                JobID: 'bar',
                Progress: 60
            }, {
                AliasName: 'foo2',
                JobID: 'bar2',
                Progress: 20
            }]), { encoding: 'utf8', flag: 'w' });

            jobInfo.notify();

            expect(jobInfo.Progress).toBe(60);
        } finally {
            fs.unlinkSync(tempFile);
        }
    });
});