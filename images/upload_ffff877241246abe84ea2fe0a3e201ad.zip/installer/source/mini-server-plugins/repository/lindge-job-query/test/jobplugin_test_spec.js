var jobPlugin = require('../index.js');

const miniserver = require('mini-server-core');
const HTTP_METHODS = miniserver.HTTP_METHODS;
const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;


/**
 * @param {Buffer} buffer
 * @returns {Any}
 */
function parseJSONFromBuffer (buffer) {
    var data = buffer.toString('utf8');
    return JSON.parse(data);
}

describe("test job plugin", function () {
    var plugin;

    beforeEach(function () {
        plugin = new jobPlugin();
    });

    it("test job create", function () {
        var jobInfo = plugin.createJob('foo', 'bar');
        expect(jobInfo.AliasName).toBe('foo');
        expect(jobInfo.JobID).toBe('bar');

        expect(function () {
            plugin.createJob('foo');
        }).toThrow();
    });

    it("test job query", function () {
        expect(plugin.getJobInfo('foo')).toBe(null);

        plugin.createJob('foo', 'bar');
        expect(plugin.getJobInfo('foo')).not.toBe(null);
    });

    it("test job removal", function () {
        plugin.createJob('foo', 'bar');
        plugin.removeJob('foo');
        expect(plugin.getJobInfo('foo')).toBe(null);
    });

    it("test job configuration loading", function () {
        plugin.loadFromFile('./test/resource/jobs.json');

        var job1 = plugin.getJobInfo('job1');
        expect(job1).not.toBe(null);
        expect(job1).toEqual(jasmine.objectContaining({
            "AliasName": "job1",
            "JobID": "job1",
            "Progress": 25,
            "CurrentStep": "",
            "JobDescription": "xxxxx",
            "Exception": "",
            "ExecutedTime": new Date("2015-10-4 14:22:20"),
            "State": "executing"
        }));

        var job2 = plugin.getJobInfo('job2');
        expect(job2).not.toBe(null);
        expect(job2).toEqual(jasmine.objectContaining({
            "AliasName": "job2",
            "JobID": "job2",
            "Progress": 60,
            "CurrentStep": "Step6",
            "JobDescription": "xxxxx",
            "Exception": "something happened",
            "State": "failed"
        }));
    });

    it("test invalid job configuration loading", function () {
        expect(function () {
            plugin.loadFromFile('./test/resource/jobs_err.json');
        }).toThrow();
    });

    it("test plugin active", function () {
        plugin.createJob('job1', 'job1').fromPlainObj({
            "Progress": 25,
            "CurrentStep": "",
            "JobDescription": "xxxxx",
            "Exception": "",
            "ExecutedTime": new Date("2015-10-4 14:22:20"),
            "State": "executing"
        });

        plugin.createJob('job2', 'job2').fromPlainObj({
            "Progress": 60,
            "CurrentStep": "Step6",
            "JobDescription": "xxxxx",
            "Exception": "something happened",
            "State": "failed"
        });

        var mockRuntime = {
            handlers: {},
            registerEXHandler: function (method, matcher, handler) {
                this.handlers[method] = handler;
            }
        };

        plugin.active(mockRuntime);
        expect(mockRuntime.handlers.hasOwnProperty(HTTP_METHODS.GET)).toBe(true);
        expect(mockRuntime.handlers.hasOwnProperty(HTTP_METHODS.POST)).toBe(true);

        // single job query
        var getHandler = mockRuntime.handlers[HTTP_METHODS.GET];
        var getRes = getHandler(null, {}, null, ['job1']);
        expect(getRes.code).toBe(HTTP_STATUS_CODE.success);
        expect(getRes.headers['Content-Type']).toBe('application/json');
        expect(parseJSONFromBuffer(getRes.data)).toEqual(jasmine.objectContaining({
            AliasName: "job1",
            JobID: "job1",
            Progress: 25,
            JobDescription: "xxxxx",
            ExecutedTime: new Date("2015-10-4 14:22:20").toJSON(),
            State: plugin.states.executing
        }));

        // multiple job query
        var postHandler = mockRuntime.handlers[HTTP_METHODS.POST];
        var postRes = postHandler(null, {}, ['job1', 'job2', 'job3']);
        expect(postRes.code).toBe(HTTP_STATUS_CODE.success);
        expect(postRes.headers['Content-Type']).toBe('application/json');
        expect(parseJSONFromBuffer(postRes.data)).toEqual({
            job1: jasmine.objectContaining({
                AliasName: "job1",
                JobID: "job1",
                Progress: 25,
                JobDescription: "xxxxx",
                ExecutedTime: new Date("2015-10-4 14:22:20").toJSON(),
                State: plugin.states.executing
            }),
            job2: jasmine.objectContaining({
                AliasName: "job2",
                JobID: "job2",
                Progress: 60,
                CurrentStep: "Step6",
                JobDescription: "xxxxx",
                Exception: "something happened",
                State: plugin.states.failed
            }),
            job3: null
        });
    });
});