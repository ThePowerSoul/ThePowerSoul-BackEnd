const util = require('util');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


function LindgeCasualstreamProxyPlugin () {
    PluginBase.call(this, 'lindge-proxy-casualstream');

    this._host = null;
    this._schema = 'http';
}

util.inherits(LindgeCasualstreamProxyPlugin, PluginBase);

/**
 * set host address for casual stream request
 *
 * @param {String} host
 * @returns {LindgeCasualstreamProxyPlugin}
 */
LindgeCasualstreamProxyPlugin.prototype.setHost = function(host) {
    if (typeof host == 'string' && host.length > 0) {
        this._host = host;
    } else {
        throw new Error("Invalid host");
    }

    return this;
};

/**
 * set host address for casual stream request
 *
 * @param {String} schema
 * @returns {LindgeCasualstreamProxyPlugin}
 */
LindgeCasualstreamProxyPlugin.prototype.setSchema = function(schema) {
    if (typeof schema == 'string' && schema.length > 0) {
        this._schema = schema;
    } else {
        throw new Error("Invalid schema");
    }

    return this;
};

LindgeCasualstreamProxyPlugin.prototype.active = function(runtime) {
    if (this._host === null) {
        throw new Error("Missing casual stream host configuration");
    } else {
        var streamUrl = `${this._schema}://${this._host}/Translayer/Bank.CasualStream/stream/`;
        var uploadUrl = `${this._schema}://${this._host}/Translayer/Bank.CasualStream/upload/`;

        runtime.registerProxyHandler(HTTP_METHODS.PUT, /Translayer\/Bank\.CasualStream\/stream/, streamUrl);
        runtime.registerProxyHandler(HTTP_METHODS.POST, /Translayer\/Bank\.CasualStream\/upload/, uploadUrl);
        runtime.registerProxyHandler(HTTP_METHODS.DELETE, /Translayer\/Bank\.CasualStream\/stream/, streamUrl);
        runtime.registerProxyHandler(HTTP_METHODS.GET, /Translayer\/Bank\.CasualStream\/stream/, streamUrl);
    }

    return this;
};


module.exports = LindgeCasualstreamProxyPlugin;