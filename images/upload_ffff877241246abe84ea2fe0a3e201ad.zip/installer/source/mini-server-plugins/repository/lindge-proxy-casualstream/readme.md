#### lindge-proxy-casualstream

配置 `CasualStream` 服务代理，包括上传和下载接口

__方法__

`setHost(host: String) -> this`

设置目标服务器主机名

`setSchema(schema: String) -> this`

设置请求协议类型，默认为 `http`

