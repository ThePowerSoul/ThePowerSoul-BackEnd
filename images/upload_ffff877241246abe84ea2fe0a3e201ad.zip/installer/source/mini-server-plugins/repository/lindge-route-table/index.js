const util = require('util');

const miniserver = require('mini-server-core');
const plugins = require('mini-server-plugins');
const PluginBase = plugins.PluginBase;


const HTTP_STATUS_CODE = miniserver.HTTP_STATUS_CODE;
const HTTP_METHODS = miniserver.HTTP_METHODS;


function LindgeRouteTablePlugin () {
    PluginBase.call(this, 'lindge-route-table');

    this._method = HTTP_METHODS.GET;
    this._urlMatcher = /Translayer\/Figure.Config\/Angular\/RouteTable/i;
    this._template = "angular.module('Figure-Config-RouteTable', []).constant('routeTable', {routeTable});";
    this._routeMapping = {};

    this._routeCache = null;
}

util.inherits(LindgeRouteTablePlugin, PluginBase);

/**
 * register route mappings
 *
 * @param {Object} mapping
 * @returns {LindgeRouteTablePlugin}
 */
LindgeRouteTablePlugin.prototype.setRoute = function(mapping) {
    var routeMapping = this._routeMapping;
    Object.keys(mapping).forEach(function (routeName) {
        routeMapping[routeName] = mapping[routeName];
    });

    this._routeCache = null;

    return this;
};

/**
 * @returns {Object}
 */
LindgeRouteTablePlugin.prototype.getRouteMapping = function() {
    return this._routeMapping;
};

/**
 * override the default url matcher
 *
 * @param {RegExp} matcher
 * @returns {LindgeRouteTablePlugin}
 */
LindgeRouteTablePlugin.prototype.setMatcher = function(matcher) {
    if (matcher instanceof RegExp) {
        this._urlMatcher = matcher;
    } else {
        throw new TypeError("Matcher must be RegExp");
    }

    return this;
};

LindgeRouteTablePlugin.prototype.active = function(runtime) {
    var routeMapping = this._routeMapping;
    var template = this._template;

    var self = this;
    runtime.registerEXHandler(this._method, this._urlMatcher, function () {
        var data;
        if (self._routeCache === null) {
            var routeStr = Object.keys(routeMapping).map(function (key) {
                return "'" + key + "': '" + routeMapping[key] + "'";
            }).join(',');

            data = template.replace(/\{\s*routeTable\s*\}/, '{' + routeStr + '}');
            this._routeCache = data;
        } else {
            data = this._routeCache;
        }

        return {
            code: HTTP_STATUS_CODE.success,
            headers: {
                'Content-Type': 'application/javascript; charset=utf-8'
            },
            data: data
        };
    });

    return this;
};


module.exports = LindgeRouteTablePlugin;