#### lindge-route-table

模拟平台的前端路由表请求，返回一段js代码，内置缓存机制

__方法__

`setRoute(mapping: Map<String, String>) -> this`

添加一组路由，如果路由已存在会进行覆盖。调用该方法后会清除路由缓存。

```javascript
plugin.setRoute({
    'config_figure_config': 'http://192.168.41.87/Translayer/Figure.Config/api/',
    'engine_alias_query': 'http://192.168.41.87/Translayer/Engine.Alias.Query/api/',
    'engine_job_query': 'http://192.168.41.87/Translayer/Engine.Job.Query/api/',
    'bank_presentation': 'http://192.168.41.87/Translayer/Bank.Presentation/',
    'bank_casualstream': '/Translayer/Bank.CasualStream/',
    'user_logon': 'http://192.168.41.87/Translayer/User.Logon/api/',
    'user_portal': 'http://192.168.41.87/Translayer/User.Portal/api/',
    'statistic_picture': 'http://192.168.41.87/Translayer/Statistic.Picture/api/',
    'operation_systemadmin': 'http://192.168.41.87/Operation/SystemAdmin/api/',
    'teacnhing_management': '/Translayer/Teaching/Management/api/'
})
```

`setMatcher(matcher: RegExp) -> this`

设置url匹配器，默认为 `/Translayer\/Figure.Config\/Angular\/RouteTable/i`
