const fs = require('fs');
const path = require('path');

const helper = require('./helper');
const isDirectory = helper.isDirectory;


function isFile (fpath) {
    try {
        return fs.statSync(fpath).isFile();
    } catch (e) {
        return false;
    }
}


function uninstall (targetPath) {
    var nodeModuleDir = path.join(targetPath, 'node_modules');
    if (isDirectory(nodeModuleDir)) {
        var cliDir = path.join(nodeModuleDir, 'mini-server-cli');
        var coreDir = path.join(nodeModuleDir, 'mini-server-core');
        var pluginDir = path.join(nodeModuleDir, 'mini-server-plugins');

        if (isDirectory(cliDir)) {
            helper.recursiveDelete(cliDir);
            console.log("mini-server-cli module uninstalled");
        } else {
            console.log("Missing `mini-server-cli` directory");
        }

        if (isDirectory(coreDir)) {
            helper.recursiveDelete(coreDir);
            console.log("mini-server-core module uninstalled");
        } else {
            console.log("Missing `mini-server-core` directory");
        }

        if (isDirectory(pluginDir)) {
            helper.recursiveDelete(pluginDir);
            console.log("mini-server-plugins module uninstalled");
        } else {
            console.log("Missing `mini-server-plugins` directory");
        }
    } else {
        console.log("Missing `node_modules` directory");
    }

    var miniserverBat = path.join(targetPath, 'miniserver.cmd');
    if (isFile(miniserverBat)) {
        fs.unlinkSync(miniserverBat);
    } else {
        console.log("Missing `miniserver.cmd` file");
    }
}

function main (args) {
    var targetPath;
    if (args.length > 1) {
        helper.errorLogAndExit("Too much arguments");
    } else if (args.length === 1) {
        targetPath = args[0];
    } else {
        targetPath = helper.getNpmPath();
        if (targetPath === null) {
            helper.errorLogAndExit("Cannot find npm directory from environment variables");
        }
    }

    if (!isDirectory(targetPath)) {
        helper.errorLogAndExit(targetPath + " is not a directory");
    } else {
        uninstall(targetPath);
        console.log("uninstall mini-server success!");
    }
}

main(process.argv.slice(2));